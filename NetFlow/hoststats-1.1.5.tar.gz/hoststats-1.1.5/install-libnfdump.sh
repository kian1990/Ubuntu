# A simple script to install libnfdump automatically
# Author: Vaclav Bartos, 2014

logfile=install-libnfdump.log
echo > $logfile

log() {
  echo "$@" | tee -a $logfile
}

cmd() {
  log "$@"
  if ! $@ >> $logfile 2>&1 ; then
    echo "ERROR: See install-libnfdump.log for details."
    exit 1
  fi
}

# Look for a file saying that installation failed in previous run due to insufficient permissions
if [ ! -e libnfdump-*/install_only ] ; then

if [ ! -e libnfdump.tar.gz ] ; then
   log
   log "################# Downloading libnfdump installation package #################"
   log
   log "wget http://sourceforge.net/projects/libnfdump/files/latest/download -O libnfdump.tar.gz"
   if ! wget http://sourceforge.net/projects/libnfdump/files/latest/download -O libnfdump.tar.gz >> $logfile 2>&1; then
      echo "ERROR: Can't download libnfdump installation package. Please download and install it manually."
      echo "Libnfdump website: http://sourceforge.net/projects/libnfdump/"
      exit 1
   fi
fi

log
log "################## Unpacking libnfdump installation package ##################"
log
cmd tar -xzf libnfdump.tar.gz

log
log "#################### Compiling libnfdump ####################"
log
cmd cd libnfdump-*
logfile="../$logfile"

confcommand="./configure --prefix=/usr"
# Trivial autodetection of 64bit system 
if [ -d /usr/lib64 ] ; then
   confcommand="$confcommand --libdir=/usr/lib64"
fi
cmd $confcommand

cmd make

else # if file install_only exists
   echo "Resuming installation ..."
   cmd cd libnfdump-*
fi

log
log "#################### Installing libnfdump ####################"
log
log "make install"
if ! make install >> $logfile 2>&1 ; then
   touch install_only
   echo
   echo "ERROR: libnfdump was successfully downloaded and compiled, but installation failed. Are you root?"
   echo "If not, re-run this script as root."
   exit 1
fi

cmd ldconfig

log
log "#################### Cleaning up ####################"
log

cmd cd ..
cmd rm -rf libnfdump-*
cmd rm -f libnfdump.tar.gz
cmd rm -f install-libnfdump.log

echo
echo "libnfdump has been installed successfully."
