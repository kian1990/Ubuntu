#!/bin/sh
#
# Simple script to install NfSen plugin template - based on install.sh
# script from SURFmap plugin
#
# Copyright (C) 2012 INVEA-TECH a.s.
# Author(s): 	Pavel Celeda <celeda@invea-tech.com>
#		Rick Hofstede <r.j.hofstede@utwente.nl>
#		Michal Trunecka <trunecka@ics.muni.cz>
# 
# Modified for HostStats by Vaclav Bartos <ibartosv@fit.vutbr.cz>
#
# LICENSE TERMS - 3-clause BSD license
#

err () {
	echo $1 >&2;
	exit 1;
}

cmd () {
   echo "$@"
   if [ ! $DRY_RUN ] ; then
      "$@"
      if [ $? != 0 ] ; then
         echo "*** Error encountered, stopping installation. ***"
         exit 1
      fi
   fi
}

print_help () {

echo "Install script for HostStats."
echo
echo "Usage:"
echo "     $0 [-d] [-c /path/nfsen.conf]"
echo "     $0 [-h]"
echo 
echo "  -d                    Dry-run - script only prints the commands"
echo "  -c /path/nfsen.conf   Path to nfsen.conf. Install script will find this file"
echo "                        automaticaly if NfSen is running"
echo "  -h                    Print this help and exit" 
echo
}


echo
echo "################################################"
echo "#  HostStats NfSen plugin installation script  #"
echo "################################################"
echo


DRY_RUN=""
NFSEN_CONF=""

while getopts ":c:dh" opt; do
	case $opt in
	c)
		echo ">>> Provided nfsen.conf: $OPTARG "
		if [ ! -e $OPTARG ]; then err "ERROR: $OPTARG does not exist."; fi
		if [ ! -r $OPTARG ]; then err "ERROR: You don't have the permission to read $OPTARG ."; fi
		echo
		NFSEN_CONF=$OPTARG
		;;
	h)
		print_help
		exit 0
		;;
	d)
		echo ">>> Dry-run mode: Nothing will be executed."
		echo
		DRY_RUN=1
		;;
	\?)
		err "Invalid option: -$OPTARG"
		;;
	esac
done


# Check that hoststatserv is compiled
if [ ! -f src/hoststatserv ]; then
   err "Please compile the sources before running install.sh (run \"./configure\" and \"make\" commands)." >&2
fi


NFSEN_VARFILE=/tmp/nfsen-tmp.conf

if [ "x$NFSEN_CONF" = "x" ]; then
	# Discover NfSen configuration
	if [ ! -n "$(ps axo command | grep \[n]fsend | grep -v nfsend-comm)" ]; then
		err "NfSen - nfsend not running. Can not detect nfsen.conf location!"
	fi
	NFSEN_LIBEXECDIR=$(cat $(ps axo command= | grep \[n]fsend | grep -v nfsend-comm | cut -d' ' -f3) | grep libexec | cut -d'"' -f2 | head -n 1)
	NFSEN_CONF=$(cat ${NFSEN_LIBEXECDIR}/NfConf.pm | grep \/nfsen.conf | cut -d'"' -f2)
	echo ">>> Using NfSen configuration found in: $NFSEN_CONF"
	echo
fi

# Parse basic info from nfsen.conf file
cat ${NFSEN_CONF} | grep -v \# | grep '=' | grep -v '=>' | egrep '\$BASEDIR|\$BINDIR|\$HTMLDIR|\$FRONTEND_PLUGINDIR|\$BACKEND_PLUGINDIR|\$WWWGROUP|\$WWWUSER|\$USER|\$PROFILEDATADIR|\$SUBDIRLAYOUT' | tr -d ';' | tr -d ' ' | cut -c2- | sed 's,/",",g' > ${NFSEN_VARFILE}
. ${NFSEN_VARFILE}
rm -rf ${NFSEN_VARFILE}

# Check permissions to install the plugin - you must be ${USER} or root
if [ "$(id -u)" != "$(id -u ${USER})" ] && [ "$(id -u)" != "0" ]; then
	err "You do not have sufficient permissions to install the NfSen plugin on this server!"
fi

if [ "$(id -u)" = "$(id -u ${USER})" ]; then
	WWWUSER=${USER}		# we are installing as normal user
fi


echo "Note: Just hit enter to use default value."
echo
printf "Enter HostStats installation directory [/data/hoststats]: "
read INSTALLDIR
if [ -z "$INSTALLDIR" ] ; then
   INSTALLDIR=/data/hoststats
fi
# remove trailing slash
INSTALLDIR=${INSTALLDIR%/}
if [ ! $DRY_RUN ] ; then
   if ! mkdir -p $INSTALLDIR ; then
      err "Can't create $INSTALLDIR"
   fi
fi

# Check whether we are updating existing installation
UPDATE=""
if [ -f ${INSTALLDIR}/hoststats.conf ] ; then
   # Check whether it is the old version 1.0.x (then the old data must be deleted)
   if grep listen-port ${INSTALLDIR}/hoststats.conf > /dev/null ; then
      OLD_UPDATE=1
      echo
      echo "** NOTICE: Existing installation of HostStats 1.0.x has been found."
      echo "The old version used fixed set of profiles: 'all', 'ssh', 'dns' and 'telnet'."
      echo "The new version uses custom user-defined profiles. The only profile predefined"
      echo "in the new version is 'all'. You can define other profiles later in the "
      echo "configuration file. Unless you plan to use profiles named 'ssh', 'dns' and "
      echo "'telnet', the old data of these profiles should be deleted (data of 'all' "
      echo "profile may remain untouched)."
      echo
      echo "(TLDR: Just hit enter 4x, data of all profiles excpet 'all' will be deleted.)"
      echo
      OLDDATADIR=$(sed -n -e "/^db-path\s*=/ { s/#.*// ; s/.*\?=\s*//p }" ${INSTALLDIR}/hoststats.conf)
      OLDDATADIR=${OLDDATADIR%/}
      if [ -z "$OLDDATADIR" ] ; then
         echo "ERROR: Can't find path to data of the old profiles. Please, remove the data manually."
      else
         printf "Delete data of 'ssh' profile (rm -rf $OLDDATADIR/ssh/)? [Y/n]"
         read REPLY
         if [ -z "$REPLY" ] || [ "$REPLY" = "y" ] || [ "$REPLY" = "Y" ]  || [ "$REPLY" = "yes" ] ; then
            cmd rm -rf $OLDDATADIR/ssh/
         fi
         printf "Delete data of 'dns' profile (rm -rf $OLDDATADIR/dns/)? [Y/n]"
         read REPLY
         if [ -z "$REPLY" ] || [ "$REPLY" = "y" ] || [ "$REPLY" = "Y" ]  || [ "$REPLY" = "yes" ] ; then
            cmd rm -rf $OLDDATADIR/dns/
         fi
         printf "Delete data of 'telnet' profile (rm -rf $OLDDATADIR/telnet/)? [Y/n]"
         read REPLY
         if [ -z "$REPLY" ] || [ "$REPLY" = "y" ] || [ "$REPLY" = "Y" ]  || [ "$REPLY" = "yes" ] ; then
            cmd rm -rf $OLDDATADIR/telnet/
         fi
         printf "Delete data of 'all' profile (rm -rf $OLDDATADIR/dns/)? [y/N]"
         read REPLY
         if [ "$REPLY" = "y" ] || [ "$REPLY" = "Y" ]  || [ "$REPLY" = "yes" ] ; then
            cmd rm -rf $OLDDATADIR/all/
         fi
      fi
      # Remove old program files
      echo
      echo "### Removing old program files and scripts"
      cmd rm -f ${INSTALLDIR}/hoststatserv
      cmd rm -f ${INSTALLDIR}/comphoststats
      cmd rm -f ${INSTALLDIR}/hoststats
      cmd rm -f ${INSTALLDIR}/hostsendwarden.pl
      cmd rm -f ${INSTALLDIR}/hscleaner.py
      echo
   else
      printf "Existing installation has been found. Do you want to keep its configuration? [Y/n] "
      read REPLY
      if [ -z "$REPLY" ] || [ "$REPLY" = "y" ] || [ "$REPLY" = "Y" ]  || [ "$REPLY" = "yes" ] ; then
         UPDATE=1
      fi
      # Check whether hoststatserv is running
      if [ -e ${INSTALLDIR}/hoststats.pid ] ; then
        printf "HostStats daemon has to be stopped in order to complete the installation. Do you want to stop it now? [Y/n] "
        read REPLY
        if [ -z "$REPLY" ] || [ "$REPLY" = "y" ] || [ "$REPLY" = "Y" ]  || [ "$REPLY" = "yes" ] ; then
           ${INSTALLDIR}/hoststats stop
        else
           echo "Installation terminated"
           exit 1
        fi
      fi
   fi
fi


if [ ! $UPDATE ] ; then
   if [ -z "$OLDDATADIR" ] ; then
      DEFAULT_DATADIR=$INSTALLDIR
   else
      DEFAULT_DATADIR=${OLDDATADIR%/data}
   fi
   printf "Enter directory for HostStats data and logs [$DEFAULT_DATADIR]: "
   read DATADIR
   if [ -z "$DATADIR" ] ; then
      DATADIR=$DEFAULT_DATADIR
   fi
   # remove trailing slash
   DATADIR=${DATADIR%/}
   if [ ! $DRY_RUN ] ; then
      if ! mkdir -p $DATADIR ; then
         err "Can't create $DATADIR"
      fi
   fi
fi

# Parse info from nfsen file needed for HostStats configuration
if [ ! $UPDATE ] ; then
   # Get path to nfsen files
   LAYOUTS_0=""
   LAYOUTS_1="%y/%m/%d/"
   LAYOUTS_2="%y/%m/%d/%H/"
   LAYOUTS_7="%y-%m-%d/"
   LAYOUTS_8="%y-%m-%d/%H/"
   if [ $SUBDIRLAYOUT -gt 2 ] && [ $SUBDIRLAYOUT -lt 7 ] ; then
      err "Directory layout used by NfSen is not supported.\n Only layouts 0,1,2,7,8 are supported by HostStats."
   fi
   LAYOUT=$(eval echo "\${LAYOUTS_$SUBDIRLAYOUT}")
   FLOW_DATA_PATH="$PROFILEDATADIR/live/%source/${LAYOUT}nfcapd.%y%m%d%H%M"
   
   
   # Parse list of sources from nfsen.conf file
   # (target format: sourcename:color,sourcename:color)
   SOURCES=$(sed -n ${NFSEN_CONF} -e "
   /^%sources\s*=\s*(\s*$/,/^\s*);/ {
     s/\s//g
     /^.*'.\+\?'=>{.*\?'col'=>'#[0-9a-fA-F]\+'.*\?},\?.*$/ {
       s/^.*'\(.\+\?\)'=>{.*\?'col'=>'#\([0-9a-fA-F]\+\)'.*\?},\?.*$/\1:\2/gp
     }
   }
   " | tr "\n" "," | head -c -1)
   if [ "x$SOURCES" = "x" ] ; then
      print "ERROR: Cannot parse flow sources (%sources array in nfsen.conf). You will have to configure it manually later."
      SOURCES=">>>FILL_THIS<<<"
      BAD_SOURCES=1
   fi
fi

echo
echo "### Copying program files and auxiliary sripts into $INSTALLDIR"
cmd cp src/hoststatserv hoststats hscleaner.py ${INSTALLDIR}/
if [ ! $UPDATE ] ; then
   cmd cp hoststats.conf.default ${INSTALLDIR}/hoststats.conf
fi
   

if [ ! $UPDATE ] ; then
   echo
   echo "### Creating subdirectories in $DATADIR"
   cmd mkdir -p $DATADIR/data
   cmd mkdir -p $DATADIR/log
fi


# Install backend and frontend plugin files
echo
echo "### Installing HostStats NfSen plugin to $FRONTEND_PLUGINDIR and $BACKEND_PLUGINDIR"
cmd cp HostStats.pm ${BACKEND_PLUGINDIR}/
cmd sed -i "s|REPLACE_THIS_BY_INSTALLATION_PATH|${INSTALLDIR}|" ${BACKEND_PLUGINDIR}/HostStats.pm
cmd cp -r frontend/* ${FRONTEND_PLUGINDIR}/
cmd sed -i "s|REPLACE_THIS_BY_INSTALLATION_PATH|${INSTALLDIR}|" ${FRONTEND_PLUGINDIR}/HostStats/app/config/config.neon


# Set permissions - owner and group
echo
echo "### Setting plugin files permissions - user \"${USER}\" and group \"${WWWGROUP}\""
cmd chown -R ${WWWUSER}:${WWWGROUP} ${FRONTEND_PLUGINDIR}/HostStats*
cmd chmod -R g+r ${FRONTEND_PLUGINDIR}/HostStats*
cmd find ${FRONTEND_PLUGINDIR}/HostStats -type d -exec chmod g+x {} \;
cmd chown -R ${USER}:${WWWGROUP} ${BACKEND_PLUGINDIR}/HostStats*


# Enable plugin
echo
echo "### Updating NfSen configuration file ${NFSEN_CONF}"

OLDENTRY=$(grep "^\@plugins" ${NFSEN_CONF})
if [ -n "$OLDENTRY" ] ; then
  HOSTSTATS_LINE=$(grep "\[.*,.*'HostStats'.*\]" ${NFSEN_CONF})
  if [ -n "${HOSTSTATS_LINE}" ] ; then
    if echo "${HOSTSTATS_LINE}" | grep "#.*\[.*,.*'HostStats'.*\]" > /dev/null ; then
      printf "HostStats is already present in the list of plugins but it's commented out. Do you want to enable it? [Y/n] "
      read REPLY
      if [ -z "$REPLY" ] || [ "$REPLY" = "y" ] || [ "$REPLY" = "Y" ]  || [ "$REPLY" = "yes" ] ; then
        cmd sed -i "s/#\+\(.*\[.*,.*'HostStats'.*\]\)/\1/" ${NFSEN_CONF}
      fi
    else
      echo "** NOTICE: HostStats is already present in the list of plugins."
    fi
  else
    cmd sed -i "s/${OLDENTRY}/${OLDENTRY}\n    \[ 'live', 'HostStats' \],/g" ${NFSEN_CONF}
  fi
else
  echo "** ERROR: \"@plugins\" array not found in ${NFSEN_CONF}, can't add HostStats to the list of plugins"
fi


# Set up HostStats configuration automatically
if [ ! $UPDATE ] ; then
   echo
   echo "### Updating HostStats configuration file $INSTALLDIR/hoststats.conf"
   
   # Paths to HostStats files
   cmd sed -i "s|^basedir.*|basedir = $INSTALLDIR/|" $INSTALLDIR/hoststats.conf
   cmd sed -i "s|^db-path.*|db-path = $DATADIR/data/|" $INSTALLDIR/hoststats.conf
   cmd sed -i "s|^detection-log.*|detection-log = $DATADIR/log/|" $INSTALLDIR/hoststats.conf
   cmd sed -i "s|^db-cleaner.*|db-cleaner = $INSTALLDIR/hscleaner.py|" $INSTALLDIR/hoststats.conf
   
   # flow-data-path and flow-sources (parsed previously from nfsen.conf)
   cmd sed -i "s|^flow-data-path.*|flow-data-path = $FLOW_DATA_PATH|" $INSTALLDIR/hoststats.conf
   cmd sed -i "s|^flow-sources.*|flow-sources = $SOURCES|" $INSTALLDIR/hoststats.conf
fi

echo
echo "********************************************************************************"
echo
echo "Please reload NfSen to finish plugin installation:"
echo "${BINDIR}/nfsen reload"
echo

if [ $BAD_SOURCES ] ; then
   echo "!! IMPORTANT: Some parameters in configuration file couldn't be set up"
   echo "!! correctly due to errors during installation. Check configuration in"
   echo "!! ${INSTALLDIR}/hoststats.conf before running HostStats!"
   echo
fi

if [ $UPDATE ] ; then 
   echo "Then you can start HostStats daemon:"
   echo "${INSTALLDIR}/hoststats start"
else
   if [ $OLD_UPDATE ] ; then 
      echo "If the old version of HostStats daemon is still running, stop it using:"
      echo "killall hoststatserv"
      echo
   fi
   echo "If you want to define HostStats profiles, edit the configuration file:"
   echo "${INSTALLDIR}/hoststats.conf"
   echo
   echo "Then you can run HostStats daemon:"
   echo "${INSTALLDIR}/hoststats start"
fi
