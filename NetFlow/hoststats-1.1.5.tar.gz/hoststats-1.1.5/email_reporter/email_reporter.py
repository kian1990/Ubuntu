#!/usr/bin/env python

import sys

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from optparse import OptionParser
import os.path
import time

# CONFIGURATION FILENAME
config_file = "email_config.cfg"

# DEFAULT SETTINGS
server =     None
port =       25
starttls =   0
login =      None
limit =      10
email_from = None
email_to =   None
link_template = None


# ------------------------------------------------------------------------------

# A message to send when a limit on number of messages per hour is reached
OUT_OF_LIMIT_SUBJECT = " (report limit reached)"
OUT_OF_LIMIT_MESSAGE = """\
Email reporter has sent the defined maximal number of messages during the last 
hour. Further messages may be supressed in order to not flood your inbox.
"""

def remaining_msg_in_limit():
	"""
	Check whether we would reach a limit by sending another message now.
	Return number of remaining emails in limit. If limit is disabled, return -1.
	"""
	if limit <= 0:
		# Limit is disabled
		return -1

	log_file_name = ".email_reporter.log"
	if not os.path.isfile(log_file_name):
		# File not exists, create new one
		open(log_file_name, 'a').close()
	
	# Get all records
	log_file = open(log_file_name, 'r+')
	content = log_file.read().splitlines()
	log_file.seek(0)

	# Remove records older than one hour
	now = int(time.time())
	content[:] = [x for x in content if int(x) > now - 3600]

	# Check number of remaining messages in limit
	if len(content) >= int(limit):
		log_file.close()
		return 0

	# Add current time
	log_file.truncate()
	log_file.write(str(now) + '\n')
	log_file.write('\n'.join(content))
	log_file.close()
	return int(limit) - len(content)


# Check arguments
simulation_only = False

argc = len(sys.argv)
if argc != 10: # HostStats always run this script with 1 + 9 arguments
	# Configuration of a parser 
	parser = OptionParser()
	parser.description = 'Script for sending HostStats event detection to '\
		'specified email address.'
	parser.epilog = 'More information in the README file.'

	parser.add_option("-s", "--simulation",
		action = "store_true", 
		default = False,
		help = 'send a sample email to verify the functionality of the configuration')

	# Parse arguments...
	(options, args) = parser.parse_args()
	if options.simulation:
		simulation_only = True
	else:
		print >> sys.stderr, 'ERROR: Unexpected number of parameters.\nTry "%s --help"'\
			' for more information.' % (sys.argv[0], sys.argv[0])
		sys.exit(1);

# Parse configuration file
f = open(config_file, "r")
config = f.read()
for i, line in enumerate(config.splitlines()):
	# Remove comments and empty lines
	if (line == "" or line.isspace()):
		continue

	pos = line.find('#')
	if (pos != -1) and (line[:pos] == "" or line[:pos].isspace()):
		continue

	var, value = line.split('=', 1)
	if value.isspace():
		print >> sys.stderr, 'Error in configuration file (line %i): \
			Each line mush have format "variable = value".' % i
		sys.exit(1)

	# Trim whitespaces
	var = var.strip()
	value = value.strip()

	# Set variables
	if var == "server" :
		server = value
	elif var == "port" :
		port = value
	elif var == "starttls" :
		starttls = (value == "1" or value.lower() == "true")
	elif var == "login" :
		login = value.split(':', 1)
	elif var == "limit" :
		limit = int(value)
	elif var == "from" :
		email_from = value
	elif var == "to" :
		email_to = value
	elif var == "link" :
		link_template = value
	else:
		print >> sys.stderr, 'Error in configuration file (line %i): \
			Unknown variable "%s".' % (i, var)
		sys.exit(1)
f.close()

# Check settings
if server is None:
	print >> sys.stderr, 'Error in configuration file: SMTP server must be set.'
	sys.exit(1)
if email_from is None:
	print >> sys.stderr, 'Error in configuration file: Email address of sender \
		("from = ...") not found. '
	sys.exit(1)
if email_to is None:
	print >> sys.stderr, 'Error in configuration file: Email address of \
		recipient ("to = ...") not found.'

if simulation_only:
	remaining_msgs = 5 # Magic constant
	event_type = "sample mail"
else:
	remaining_msgs = remaining_msg_in_limit()
	event_type = sys.argv[2]

subject = "HostStats: event detection [" + event_type + "]"

# Check whether we would reach a limit by sending this message
if remaining_msgs == 0 and limit > 0:
	sys.exit(0) # Out of limit
elif remaining_msgs == 1:
	subject += OUT_OF_LIMIT_SUBJECT

# Create message container
msg = MIMEMultipart('alternative')
msg['Subject'] = subject
msg['From'] = email_from
msg['To'] = email_to

text_message = ""
html_message = ""

# Body of message
if simulation_only:
	text_message = "HostStats\nEmail reporter configuration SUCCESS."
	html_message = \
		"<html><body>\
		HostStats<br>Email reporter configuration SUCCESS.\
		</body></html>"
else:
	# - Plain-text of the message
	text_message = \
		"HostStats: event detection:\n"\
		"\n"\
		"Timeslot:         %s\n" % sys.argv[1] + \
		"Event type:       %s\n" % sys.argv[2] + \
		"Protocol:         %s\n" % sys.argv[3] + \
		"Source IP:        %s\n" % sys.argv[4] + \
		"Source port:      %s\n" % sys.argv[6] + \
		"Destination IP:   %s\n" % sys.argv[5] + \
		"Destination port: %s\n" % sys.argv[7] + \
		"Event scale:      %s\n" % sys.argv[8] + \
		"Note:             %s\n" % sys.argv[9]

	if link_template and sys.argv[4]:
		text_message += "\nLink to HostStats page with details about the source address at the event time:\n"
		text_message += link_template + "?presenter=History&ip=%s&from=%s&to=%s" % (sys.argv[4], sys.argv[1], sys.argv[1])

	if (remaining_msgs == 1):
		# Add warning message
		text_message += "\n" + OUT_OF_LIMIT_MESSAGE

	# - HTML version of the message
	def html_table_row(name, value):
		row = "<tr>" \
			+ "<td style=\"border: 1px solid black; padding: 2px 4px 2px 4px;"\
			+ 	"width:130px; background-color: #0066CC; color: white\">"\
			+ name + "</td>"\
			+ "<td style=\"border: 1px solid black; padding: 2px 4px 2px 4px;\">"\
			+ value + "</td>" \
			+ "</tr>"
		return row

	html_message = \
		"<html><body style=\"font-family: Arial, sans-serif\">" \
		+ "<center>" \
		+ "<h2 style=\"font-size: 1.3em\">HostStats: event detection</h2>"

	if (remaining_msgs == 1):
		# Add warning message
		html_message += \
			"<div style=\"background-color:red; color:white; " \
			+ "padding: 4px 4px 4px 4px; max-width: 500px; width: 100%;\">" \
			+ OUT_OF_LIMIT_MESSAGE \
			+ "</div><br>"

	html_message += \
		"<table style=\"border-collapse:collapse; border: 2px solid black;"\
		+   "max-width: 500px; width: 100%; text-align: center; \">" \
		+ html_table_row("Timeslot",         sys.argv[1]) \
		+ html_table_row("Event type",       sys.argv[2]) \
		+ html_table_row("Protocol",         sys.argv[3]) \
		+ html_table_row("Source IP",        sys.argv[4]) \
		+ html_table_row("Source port",      sys.argv[6]) \
		+ html_table_row("Destination IP",   sys.argv[5]) \
		+ html_table_row("Destination port", sys.argv[7]) \
		+ html_table_row("Event scale",      sys.argv[8]) \
		+ html_table_row("Note",             sys.argv[9]) \
		+ "</table>"
	
	if link_template and sys.argv[4]:
		link = link_template + "?presenter=History" + "&amp;ip=%s&amp;from=%s&amp;to=%s" % (sys.argv[4], sys.argv[1], sys.argv[1])
		html_message += "<p>Click here for <a href=\"%s\">details about the source address at the event time</a>.</p>" % link

	html_message += \
		"<p>This is automatically generated email, don't reply.</p>" \
		+ "</center>" \
		+ "</body></html>"

# Add all parts of the email
msg.attach(MIMEText(text_message, 'plain'))
msg.attach(MIMEText(html_message, 'html'))

# Send mail
try:
	smtp = smtplib.SMTP(timeout = 10)
	smtp.connect(server, port)
	if starttls:
		smtp.starttls()
	if login:
		smtp.login(login[0], login[1])

	smtp.sendmail(email_from, email_to, msg.as_string())
	smtp.quit()
	# Success....

except smtplib.SMTPException, e:
	# Error:
	print >> sys.stderr, 'Error: unable to send email'
	print >> sys.stderr, e
	sys.exit(1)
