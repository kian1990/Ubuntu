#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>
#include <sstream>
#include <cerrno>
#include <cstdlib>
#include <cstring>
#include <iostream>

#include "aux_func.h"
#include "script.h"


/**
 * \brief Execute script
 * Check if the specified file exists and this process has permissions 
 * to execute it. Then starts execution of the script and wait until its end.
 * @return 0 on success, otherwise -1
 */
int Script::execute() 
{
   log(LOG_DEBUG, "Executing script '%s' ...", file_path.c_str());

   // Check file and permissions
   if (access(file_path.c_str(), F_OK | X_OK) == -1) {
      log(LOG_ERR, "Script '%s' doesn't exist or process doesn't have "
              "permission to execute it.", file_path.c_str());
      return -1;
   }

   // Get directory and filename
   std::string dir, file;
   size_t pos = file_path.find_last_of('/');

   if (pos != std::string::npos) {
       dir = file_path.substr(0, pos);
       file = file_path.substr(pos + 1);
   } else {
       file = file_path;
   }

   // Convert filename (string) to char* and args (vector of strings) to C-array of char* 
   char **c_args = new char*[args.size()+2]; // +1 filename, +1 NULL at the end
   c_args[0] = new char[file.size()+1];
   strcpy(c_args[0], file.c_str());
   unsigned int i = 0;
   for ( ; i < args.size(); i++) {
      c_args[i+1] = new char[args[i].size()+1];
      strcpy(c_args[i+1], args[i].c_str());
   }
   c_args[i+1] = NULL;

   int status;
   pid_t pid;

   pid = fork();
   if (pid == 0) {
      // Script executor
      // Change directory
      if (!dir.empty()) {
         if (chdir(dir.c_str()) != 0) {
            log(LOG_ERR, "Script executor failed to change directory to '%s': %s",
               dir.c_str(), strerror(errno));
            exit(0);
         }
      }
      // Child, exec script
      execv(c_args[0], &c_args[0]);
      log(LOG_ERR, "Failed to execute '%s'", file_path.c_str());
      exit(0);
   } else if (pid != -1) {
      // Parent, wait until child ends
      if (waitpid(pid, &status, 0) == -1) {
         log(LOG_ERR, "waitpid() error: %s", strerror(errno));
      } else if (!WIFEXITED(status)) {
         log(LOG_ERR, "'%s' exited abnormally.", file_path.c_str());
      } else if (WEXITSTATUS(status) != 0) {
         log(LOG_ERR, "Script execution probably failed. '%s' returned %i.", 
            file_path.c_str(), WEXITSTATUS(status));
      } else {
         log(LOG_INFO, "Execution of the script '%s' was completed.", file_path.c_str());
         // Cleanup
         for (unsigned int i = 0; i < args.size() + 1; i++)
            delete[] c_args[i];
         delete[] c_args;
         
         return 0;
      }
   } else {
      // Fork error
      log(LOG_ERR, "Can't execute the script. Fork error.");
   }
   
   // Cleanup
   for (unsigned int i = 0; i < args.size() + 1; i++)
      delete[] c_args[i];
   delete[] c_args;
   
   return -1;
}

/**
 * \brief Remove all passed arguments
 */
void Script::remove_args()
{
    args.clear();
}

/**
 * \brief Print arguments
 * This function is only for testing purposes. 
 */
void Script::print_args()
{
   for (std::vector<std::string>::const_iterator it = args.begin(); 
      it != args.end(); ++it) {
      std::cout << *it << std::endl;
   }
}

