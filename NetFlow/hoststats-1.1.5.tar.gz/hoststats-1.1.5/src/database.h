#ifndef _HS_DATABASE_H
#define _HS_DATABASE_H

#include <string>
#include <vector>
#include "hoststats.h" // stat_map_t, host_key_t, host_rec_t

// Numbers of hosts/flows/packets/bytes in a file
struct DatabaseStats {
   uint32_t hosts;
   uint32_t flows;
   uint64_t packets;
   uint64_t bytes;
};


class Database {
protected:
   std::string profile_name;
   std::string path;
   std::string max_db_size;
   bool read_only;
public:
   static std::string db_cleaner;
   
   Database(const std::string& profile_name, const std::string& max_db_size);
   int connect(const std::string &base_path, bool read_only = false);
   int disconnect();
   int reloadConfig();
   int store(const std::string &timeslot, const stat_map_t &stat_map) const;
   int load(const std::string &timeslot, stat_map_t &stat_map) const;
   int cleanup() const;
   int getRecord(const std::string& timeslot, const hosts_key_t &key, hosts_record_t &rec) const;
   std::vector<std::string> getTimeslots(const std::string &start = "", const std::string &end = "") const;
   int getNumOfRecords(const std::string &timeslot) const;
   int getStats(const std::string &timeslot, DatabaseStats &stats) const;
   
   static int storeToFile(const std::string &filename, const stat_map_t &stat_map);
};

#endif
