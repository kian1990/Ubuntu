/*
<stat> -> ( ... ( <stat>
<stat> -> number <bracket>
<stat> -> number <op> <stat2>
<stat> -> <dir> <item> <bracket>
<stat> -> <dir> <item> <op> <stat2>
<stat> -> <item> <bracket>
<stat> -> <item> <op> <stat2>

<stat2> -> ( ... ( <stat2>
<stat2> -> <bracket>
<stat2> -> number EOF
<stat2> -> number <bracket>
<stat2> -> number <log-op> <stat3>
<stat2> -> number <op> <stat2>
<stat2> -> <dir> <item> EOF
<stat2> -> <dir> <item> <bracket>
<stat2> -> <dir> <item> <log-op> <stat3>
<stat2> -> <dir> <item> <op> <stat2>
<stat2> -> <item> EOF
<stat2> -> <item> <bracket>
<stat2> -> <item> <log-op> <stat3>
<stat2> -> <item> <op> <stat2>

<stat3> -> ( ... ( <stat2>
<stat3> -> <dir> <item> <op> <stat2>
<stat3> -> <item> <op> <stat2>
<stat3> -> <links> <log-op> <stat3>
<stat3> -> <links> EOF

<bracket> -> ) ... ) EOF
<bracket> -> ) ... ) <log-op> <stat3>
<bracket> -> ) ... ) <op> <stat2>

<dir> -> in|out

<item> -> bytes|packets|flows|syn|fin|rst|psh|urg|ack

<op> -> >
<op> -> <
<op> -> =
<op> -> !=
<op> -> >=
<op> -> <=
<op> -> +
<op> -> -
<op> -> *
<op> -> /

<log-op> -> and
<log-op> -> or

<links> -> from links [ <link-item> <link-list>

<link-list> -> ]
<link-list> -> , <link-item> <link-list>

<link-item> -> aconet|amsix|geant|nix2|nix3|pioneer|sanet|telia|telia2
*/

#ifndef SYNAN_H
#define SYNAN_H

#include <stdint.h>

#include "lexan.h"
#include "hoststats.h"

enum errors {
   E_OK,
   E_FIRST_LVL,
   E_PARENTHESES,
   E_SYNTACTIC_ERROR,
   E_INTERNAL
};

enum dr_tree_types {
   TYPE_EMPTY,
   TYPE_NUM,
   TYPE_ITEM,
   TYPE_OP,
};

enum modes {
   MODE_BOTH,
   MODE_IN,
   MODE_OUT
};

enum data_types {
   DATA_NUM,
   DATA_ITEM
};

enum caller_types {
   CALLER_STAT,
   CALLER_STAT2
};

// Priority of operators
extern int ops_map[];

class DrTreeNode {
protected:
   bool full;

public:
   bool positive;
   bool resolved;
   bool first;

   int data;
   int mode;
   int par_left;
   int par_right;
   int type;
   int value;

   uint64_t mask;

   DrTreeNode *l_ptr;
   DrTreeNode *r_ptr;

   DrTreeNode *root;

   DrTreeNode **active;

   DrTreeNode() {
      first = false;
      full = false;
      positive = true;
      resolved = false;
      par_left = 0;
      par_right = 0;
      type = TYPE_EMPTY;
      mode = MODE_BOTH;
      mask = 0x0;
      root = NULL;
      l_ptr = NULL;
      r_ptr = NULL;
      active = &l_ptr;
   };
   ~DrTreeNode() {
      Delete();
   }

   int AddNewRoot(DrTreeNode *new_root);
   int AddNewBranch(DrTreeNode *new_branch);
   int Copy(DrTreeNode *new_tree);
   void Delete();
   int Insert(DrTreeNode *node);
   bool IsFull();
   int MoveActive();
   void Negate();
   int Optimize();
   void Print();
   int Resolve();
   int Update(const hosts_record_t &rec);
};

class Synan {
protected:
   int pars;
   int mode;

   DrTreeNode *tree;
   DrTreeNode *current;
   Lexan *lex;

   int bracket(int caller);
   int dir();
   int item();
   int links();
   int link_list();
   int link_item();
   int log_op();
   int op();
   int stat();
   int stat2();
   int stat3();

   int SaveData(int data_type);

public:
   Synan(string request) {
      lex = new Lexan(request);
      pars = 0;
      mode = MODE_BOTH;
      tree = new DrTreeNode;
      current = tree;
   };
   ~Synan() {
      delete tree;
      delete lex;
   };

   int Execute(const stat_map_t &in_stat_map, vector<pair<hosts_key_t, hosts_record_t> > &out_stat_map);
};

#endif
