#ifndef LEXAN_H
#define LEXAN_H

#include <string>

/*
start
c()                  -> start
c(+, -, *, /, (, ), [, ], =, EOF)
                     -> return
c(,)                 -> return
c(a, A, _)           -> alnum
c(#)                 -> num
c(>)                 -> bigger
c(<)                 -> smaller
c(!)                 -> excl
c(else)              -> error

alnum
c()                  -> return
c(+, -, *, /, >, <, =, !, (, ), [, ], ,, EOF)
                     -> return
c(,)                 -> return
c(a, A, _, #)        -> alnum
c(else)              -> error

num
c()                  -> return
c(+, -, *, /, >, <, =, !, ), EOF)
                     -> return
c(.)                 -> only_num
c(e)                 -> e_state
c(#)                 -> num
c(else)              -> error

only_num
c(#)                 -> num_end
c(else)              -> error

num_end
c()                 -> return
c(+, -, *, /, >, <, =, !, EOF)
                     -> return
c(,)                 -> return
c(#)                 -> only_num_end
c(else)              -> error

e_state
c(+,-,#)             -> only_num
c(else)               -> error

bigger
c(=)                 -> return >=
c(else)              -> return >

smaller
c(=)                 -> return <=
c(else)              -> return <

excl
c(=)                 -> return !=
c(else)              -> error
*/

// If you change this, change also op_priority array in synan.h
enum lexan_ret {
   TOKEN_ERROR,      // 0
   TOKEN_EOF,        // 1
   TOKEN_NUMBER,     // 2
   // Operators
   TOKEN_PLUS,       // 3
   TOKEN_MINUS,      // 4
   TOKEN_STAR,       // 5
   TOKEN_SLASH,      // 6
   TOKEN_LBRACKET,   // 7
   TOKEN_RBRACKET,   // 8
   TOKEN_LSBRACKET,  // 9
   TOKEN_RSBRACKET,  // 10
   TOKEN_EQUAL,      // 11
   TOKEN_UNEQUAL,    // 12
   TOKEN_BIGGER,     // 13
   TOKEN_SMALLER,    // 14
   TOKEN_SMEQUAL,    // 15
   TOKEN_BEQUAL,     // 16
   TOKEN_COMMA,      // 17
   TOKEN_AND,        // 18
   TOKEN_OR,         // 19
   TOKEN_NOT,        // 20
   TOKEN_FROM,       // 21
   // Keywords
   TOKEN_SRC,        // 22
   TOKEN_DST,        // 23
   TOKEN_IN,         // 24
   TOKEN_OUT,        // 25
   TOKEN_BYTES,      // 26
   TOKEN_PACKETS,    // 27
   TOKEN_FLOWS,      // 28
   TOKEN_SYN,        // 29
   TOKEN_FIN,        // 30
   TOKEN_RST,        // 31
   TOKEN_PSH,        // 32
   TOKEN_URG,        // 33
   TOKEN_ACK,        // 34
   TOKEN_LINKS,      // 35
   TOKEN_MIN,        // 36
   TOKEN_MAX,        // 37
   TOKEN_UNKNOWN     // 38
};

using namespace std;

class Lexan
{
   bool enabled;
   string read_str;
   int len;
   int index;

   bool is_bin_op(int c);  // Is binary operator

public:
   int last_rc;
   int token_index;
   string last_token;

   Lexan(string str)
   {
      token_index = 0;
      enabled = true;
      read_str = str;
      len = read_str.length();
      index = 0;
   };

   void disable();
   void enable();
   int get_token();

protected:
   int keyword();
};

#endif
