#include <string>
#include <vector>
#include <fstream>
#include <stdlib.h>
#include <dirent.h>
#include <errno.h>
#include <sys/stat.h>
#include <algorithm>

#include "aux_func.h"
#include "configuration.h"
#include "database.h"

using namespace std;

const char *struct_spec = "address,16"
   ";in_flows,4;out_flows,4;in_packets,8;out_packets,8;in_bytes,8;out_bytes,8"
   ";in_syn_cnt,4;out_syn_cnt,4;in_ack_cnt,4;out_ack_cnt,4;in_fin_cnt,4;out_fin_cnt,4"
   ";in_rst_cnt,4;out_rst_cnt,4;in_psh_cnt,4;out_psh_cnt,4;in_urg_cnt,4;out_urg_cnt,4"
   ";in_uniqueips,4;out_uniqueips,4;in_linkbitfield,8;out_linkbitfield,8"
   "\n";


string Database::db_cleaner;

Database::Database(const string& profile_name, const string& max_db_size)
 : profile_name(profile_name), max_db_size(max_db_size)
{ }

int Database::connect(const string &base_path, bool read_only)
{
   if (base_path.empty())
      return -1;
   
   path = base_path;
   
   // Make sure that path ends with '/'
   if (path[path.size()-1] != '/')
      path += '/';
   
   // Append profile_name to path
   path += profile_name + '/';
   
   // Create a directory for profile if it doesn't exist
   if (mkdir(path.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH) != 0) {
      if (errno != EEXIST) {
         log(LOG_ERR, "Database: Can't create directory \"%s\": %s",
             path.c_str(), strerror(errno));
         return -2;
      }
   }
   // TODO: check whether we can read/write from/into path
   
   this->read_only = read_only;
   
   return 0; 
}

int Database::disconnect()
{
   return 0;
}



// Run database cleaner script, if defined
int Database::cleanup() const
{
   if (db_cleaner.empty() || max_db_size.empty())
      return -1;
      
   // Prepare command
   string command = db_cleaner + " " + path + " " + max_db_size;
   log(LOG_DEBUG, "Running database cleaner: '%s'", command.c_str());
   // Run the command and wait for result
   if (system(command.c_str()) != 0)  {
      log(LOG_ERR, "Database cleaner exited with error. Command: '%s'", command.c_str());
      return -2;
   }
   return 0;
}

int Database::store(const std::string &timeslot, const stat_map_t &stat_map) const
{
   if (path.empty())
      return -1;
   if (read_only) {
      return 1;
   }
   
   // Run database cleaner script
   cleanup();
   
   // Store data into a file
   string filename = path + "hs." + timeslot;
   int ret = storeToFile(filename, stat_map);
   if (ret != 0) {
      return ret; // some error occured
   }
   
   log(LOG_DEBUG, "Statistics stored into '%s'", filename.c_str());
   return 0;
}


int Database::storeToFile(const string &filename, const stat_map_t &stat_map)
{
   // Open a file
   ofstream file(filename.c_str(), ofstream::out | ofstream::trunc | ofstream::binary);
   
   if (!file.good()) {
      file.close();
      log(LOG_ERR, "Database: Can't open file '%s' for writing.", filename.c_str());
      return -1; // Error when opening file
   }
   
   uint32_t cnt_hosts = 0;
   uint32_t cnt_flows = 0;
   uint64_t cnt_packets = 0;
   uint64_t cnt_bytes = 0;
   
   // Write file header
   uint16_t spec_len = string(struct_spec).size();
   file.write("HS\001\001", 4); // file type identification and version
   // Leave space for numbers of hosts(4B)/flows(4B)/packets(8B)/bytes(8B) (added in ver 1.1)
   char tmp[24] = {0,};
   file.write(tmp, 24);
   // Write struct specification string
   file.write((char*)(&spec_len), 2); // length of struct specification string
   file.write(struct_spec, spec_len); // specification string
   
   // Write data
   for (stat_map_t::const_iterator it = stat_map.begin(); it != stat_map.end(); ++it) {
      file.write(reinterpret_cast<const char*>(&it->first), sizeof(it->first)); // address
      file.write(reinterpret_cast<const char*>(&it->second), sizeof(it->second)); // statistics
      // Count number of hosts/flows/packets/bytes
      cnt_hosts += 1;
      cnt_flows += it->second.in_flows;
      cnt_packets += it->second.in_packets;
      cnt_bytes += it->second.in_bytes;
   }
   
   // Write number of hosts/flows/packets/bytes
   file.seekp(4);
   file.write(reinterpret_cast<const char*>(&cnt_hosts), 4);
   file.write(reinterpret_cast<const char*>(&cnt_flows), 4);
   file.write(reinterpret_cast<const char*>(&cnt_packets), 8);
   file.write(reinterpret_cast<const char*>(&cnt_bytes), 8);
   
   if (!file.good()) {
      log(LOG_ERR, "Database: Some error has occured during writing into file '%s'.", filename.c_str());
      file.close();
      return -2;
   }
   
   // Close file
   file.close();
   return 0;
}


int Database::load(const string &timeslot, stat_map_t &stat_map) const
{
   if (path.empty())
      return -1;
   
   // Open file for reading
   string filename = path + "hs." + timeslot;
   ifstream file(filename.c_str(), ifstream::in | ifstream::binary);
   
   if (!file.good()) {
      file.close();
      log(LOG_ERR, "Database: Can't open file '%s' for reading.", filename.c_str());
      return -2; // Error when opening file
   }
   
   // Read file header
   char *buffer = new char[4];
   file.read(buffer, 4);
   
   if (!file.good() || buffer[0] != 'H' || buffer[1] != 'S') {
      file.close();
      delete[] buffer;
      return -3; // not a valid HostStats file
   }
   // Check version
   if (buffer[2] == '\001' && buffer[3] == '\001') { //v1.1 - skip 24 bytes
      file.seekg(24, ios_base::cur);
   }
   else if (buffer[2] == '\001' && buffer[3] == '\000') { //v1.0 - no action nmecessary
   }
   else { // unknown version
      file.close();
      delete[] buffer;
      return -4; // unknown file version
   }
   
   // Read length of struct specification string
   file.read(buffer, 2);
   uint16_t spec_len = *(uint16_t*)(buffer);
   
   delete[] buffer;
   buffer = new char[spec_len+1];
   file.read(buffer, spec_len);
   buffer[spec_len] = '\0';
   
   if (!file.good()) {
      file.close();
      delete[] buffer;
      return -5;
   }
   
   // Read all records
   stat_map.clear();
   if (string(struct_spec) == buffer) {
      // It's in the same format as the hosts_record_t, read directly into the struct
      hosts_key_t key;
      hosts_record_t rec;
      
      while (1) { 
         file.read((char*)&key, sizeof(key));
         file.read((char*)&rec, sizeof(rec));
         if (!file.good())
            break;
         stat_map.insert(make_pair(key,rec));
      }
   }
   else {
      // format is different from hosts_record_t, read field by field
      log(LOG_ERR, "Database: Records in file '%s' have unknown format, can't read.", filename.c_str());
      // TODO
      delete[] buffer;
      file.close();
      return -10;
   }
   
   // Cleanup
   delete[] buffer;
   file.close();
   
   // Return records
   return stat_map.size();
}

// When record is found, store it into rec and return 0. Otherwise return error code.
int Database::getRecord(const string& timeslot, const hosts_key_t &key, hosts_record_t &rec) const
{
   if (path.empty())
      return -1;
   
   // Open file for reading
   string filename = path + "hs." + timeslot;
   ifstream file(filename.c_str(), ifstream::in | ifstream::binary);
   
   if (!file.good()) {
      file.close();
      return -2; // Error when opening file
   }
   
   // Read file header
   char *buffer = new char[4];
   file.read(buffer, 4);
   
   if (!file.good() || buffer[0] != 'H' || buffer[1] != 'S') {
      file.close();
      delete[] buffer;
      return -3; // not a valid HostStats file
   }
   // Check version
   if (buffer[2] == '\001' && buffer[3] == '\001') { //v1.1 - skip 24 bytes
      file.seekg(24, ios_base::cur);
   }
   else if (buffer[2] == '\001' && buffer[3] == '\000') { //v1.0 - no action nmecessary
   }
   else { // unknown version
      file.close();
      delete[] buffer;
      return -4; // unknown file version
   }
   
   // Read length of struct specification string
   file.read(buffer, 2);
   uint16_t spec_len = *(uint16_t*)(buffer);
   
   delete[] buffer;
   buffer = new char[spec_len+1];
   file.read(buffer, spec_len);
   buffer[spec_len] = '\0';
   
   if (!file.good()) {
      file.close();
      delete[] buffer;
      return -5;
   }
   
   // Find record
   bool found = false;
   if (string(struct_spec) == buffer) {
      // It's in the same format as the hosts_record_t, read directly into the struct

      // Get number of records in the file
      long header_size = file.tellg();
      file.seekg(0, istream::end);
      long filelen = file.tellg();
      file.seekg(header_size, istream::beg);
      const int record_size = sizeof(hosts_key_t) + sizeof(hosts_record_t); 
      long n = (filelen - header_size) / record_size;
      
      // Find a record with given field using binary search (records are stored sorted)
      hosts_key_t my_key;
      long a = 0;
      long b = n-1;
      while (a <= b) {
         long i = (a+b)/2;
         file.seekg(header_size + i*record_size);
         file.read((char*)&my_key, sizeof(hosts_key_t));
         if (key < my_key) {
            b = i-1;
         }
         else if (key > my_key) {
            a = i+1;
         }
         else { // Found
            file.read((char*)&rec, sizeof(hosts_record_t));
            found = true;
            break;
         }
      }
      // **********
   }
   else {
      // format is different from hosts_record_t, read field by field
      
      // TODO
      log(LOG_ERR, "Database: Records in file '%s' have unknown format, can't read.", filename.c_str());
      delete[] buffer;
      file.close();
      return -10;
   }
   
   // Cleanup
   delete[] buffer;
   file.close();
   
   // If record was not found, fill rec with zeros
   if (!found) {
      memset(&rec, 0, sizeof(rec));
      return 1;
   }
   return 0;
}




// Return list of all available timeslots between given start and end (inclusive)
vector<string> Database::getTimeslots(const string &start, const string &end) const
{
   vector<string> timeslots;
   
   if (path.empty()) {
      log(LOG_ERR, "getTimeslots: Path to files with statistics is not set.");
      return timeslots;
   }
   
   // Open directory
   DIR *dir = opendir(path.c_str());
   if (!dir) {
      log(LOG_ERR, "getTimeslots: Can't open directory '%s': %s\n", path.c_str(), strerror(errno));
      return timeslots;
   }
   
   // Get all entries in directory
   dirent *entry;
   while ( (entry = readdir(dir)) ) {
      string name = string(entry->d_name);
      
      // Check if the name matches "hs.[0-9]{12}"
      if (name.length() != 15 || name.substr(0,3) != "hs.")
         continue;
      name = name.substr(3);
      if (name.find_first_not_of("0123456789") != string::npos)
         continue;
      
      // If start and end times are specified, check if name is between them
      if (!start.empty() && name < start)
         continue;
      if (!end.empty() && name > end)
         continue;
      
      // Store name in list of matching timeslots
      timeslots.push_back(name);
   }
   
   // Sort timeslots
   sort(timeslots.begin(), timeslots.end());
   
   // Close directory
   closedir(dir);
   return timeslots;
}


// Return number of records in a file.
// On error return negative value.
int Database::getNumOfRecords(const string &timeslot) const
{
   if (path.empty()) {
      log(LOG_ERR, "getNumOfRecords: Path to files with statistics is not set.");
      return -1;
   }
   
   // Get number of records in the file
   struct stat st;
   string filename = path + "hs." + timeslot;
   if (stat(filename.c_str(), &st) != 0) {
      log(LOG_ERR, "getNumOfRecords: Can't stat file \"%s\": %s", filename.c_str(), strerror(errno));
      return -2;
   }
   long filelen = st.st_size;
   int spec_len = string(struct_spec).size();
   long header_size = spec_len + 6;
   const int record_size = sizeof(hosts_key_t) + sizeof(hosts_record_t); 
   return ((filelen - header_size) / record_size);
}

// Return number of records in a file.
// On error return negative value.
int Database::getStats(const string &timeslot, DatabaseStats &stats) const
{
   if (path.empty()) {
      log(LOG_ERR, "getStats: Path to files with statistics is not set.");
      return -1;
   }
   
   // Read total numbers of hosts/flows/packets/bytes from file
   
   // Open file for reading
   string filename = path + "hs." + timeslot;
   ifstream file(filename.c_str(), ifstream::in | ifstream::binary);
   if (!file.good()) {
      file.close();
      log(LOG_ERR, "getStats: Can't open file '%s' for reading.", filename.c_str());
      return -2; // Error when opening file
   }
   
   // Read file header
   char *buffer = new char[24];
   file.read(buffer, 4);
   if (!file.good() || buffer[0] != 'H' || buffer[1] != 'S') {
      file.close();
      delete[] buffer;
      return -3; // not a valid HostStats file
   }
   // Check version
   if (buffer[2] == '\001' && buffer[3] == '\000') { // v1.0 - return all zeros
      stats.hosts = 0;
      stats.flows = 0;
      stats.packets = 0;
      stats.bytes = 0;
      file.close();
      delete[] buffer;
      return 0;
   }
   else if (buffer[2] == '\001' && buffer[3] == '\001') { // v1.1
      // Read stats
      file.read(buffer,24);
      stats.hosts = *(uint32_t*)(buffer);
      stats.flows = *(uint32_t*)(buffer + 4);
      stats.packets = *(uint64_t*)(buffer + 8);
      stats.bytes = *(uint64_t*)(buffer + 16);
      file.close();
      delete[] buffer;
      return 0;
   }
   else { // unknown version
      file.close();
      delete[] buffer;
      return -4; // unknown file version
   }
}


