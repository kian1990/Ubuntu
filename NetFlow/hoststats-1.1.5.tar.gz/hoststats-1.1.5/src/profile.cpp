#include "profile.h"
#include "aux_func.h"
#include "configuration.h"
// #include "processdata.h"

using namespace std;

const uint64_t MEMORY_LIMIT = 2LL*1024LL*1024LL*1024LL; // Maximum number of bytes consumed by host-stats (2GB)
const uint64_t MAX_NUM_OF_HOSTS = MEMORY_LIMIT / sizeof(hosts_record_t);

// TODO: Count total number of hosts over all profiles

// Global vector of profiles available
vector<Profile*> profiles;

Profile::Profile(const string &name, const string& filter, const string& max_size,
                 const std::string color, const string &desc)
 : name(name), desc(desc), color(color), filter(filter), database(name, max_size)
{ } 

Profile::~Profile()
{ }

// int Profile::reload_config()
// {
//    database.reloadConfig();
// }


void Profile::new_timeslot(const string &timeslot)
{
   current_timeslot = timeslot;
   
   // Clear statistics
   current_stat_map.clear();
   
   // Create bloom filter used for approximation of uniqueips statistic
   bloom_parameters bp;
   bp.projected_element_count = 5000000;
   bp.false_positive_probability = 0.01;
   bp.compute_optimal_parameters();
   log(LOG_DEBUG, "new_timeslot: Creating Bloom Filter, table size: %d, hashes: %d",
       bp.optimal_parameters.table_size, bp.optimal_parameters.number_of_hashes);
   bfilter = bloom_filter(bp);
   
   flows = 0;
   too_much_hosts_error_printed = false;
}

// Add new flow into statistics
void Profile::put_flow(const flow_key_t &flow_key, const flow_record_t &flow_rec)
{
   // Abort procesing if there are too many hosts
   if (current_stat_map.size() > MAX_NUM_OF_HOSTS) {
      if (!too_much_hosts_error_printed) {
         too_much_hosts_error_printed = 1;
         log(LOG_ERR, "Too much hosts (more than %lu), memory limit reached. "
             "The rest of data in this timeslot will be ignored.", MAX_NUM_OF_HOSTS);
      }
      return;
   }
   
   // find/add record in bloom filter
   IPAddr bkey[2] = {flow_key.sad, flow_key.dad};
   bool present = false;
   present = bfilter.containsinsert((const unsigned char *) bkey, 32);
   
   // Get source and destination address and corresponding records
   hosts_key_t src_host_key = flow_key.sad;
   hosts_key_t dst_host_key = flow_key.dad;

   hosts_record_t& src_host_rec = current_stat_map[src_host_key];
   hosts_record_t& dst_host_rec = current_stat_map[dst_host_key];

   // Update the record of src addr
   src_host_rec.out_bytes += flow_rec.bytes;
   src_host_rec.out_packets += flow_rec.packets;
   if (!present) src_host_rec.out_uniqueips++;
   src_host_rec.out_flows++;

   if (flow_rec.tcp_flags & 0x1)
      src_host_rec.out_fin_cnt++;
   if (flow_rec.tcp_flags & 0x2)
      src_host_rec.out_syn_cnt++;
   if (flow_rec.tcp_flags & 0x4)
      src_host_rec.out_rst_cnt++;
   if (flow_rec.tcp_flags & 0x8)
      src_host_rec.out_psh_cnt++;
   if (flow_rec.tcp_flags & 0x10)
      src_host_rec.out_ack_cnt++;
   if (flow_rec.tcp_flags & 0x20)
      src_host_rec.out_urg_cnt++;

   src_host_rec.out_linkbitfield |= flow_rec.linkbitfield;
   
   // Update the record of dst addr
   dst_host_rec.in_bytes += flow_rec.bytes;
   dst_host_rec.in_packets += flow_rec.packets;
   if (!present) dst_host_rec.in_uniqueips++;
   dst_host_rec.in_flows++;

   if (flow_rec.tcp_flags & 0x1)
      dst_host_rec.in_fin_cnt++;
   if (flow_rec.tcp_flags & 0x2)
      dst_host_rec.in_syn_cnt++;
   if (flow_rec.tcp_flags & 0x4)
      dst_host_rec.in_rst_cnt++;
   if (flow_rec.tcp_flags & 0x8)
      dst_host_rec.in_psh_cnt++;
   if (flow_rec.tcp_flags & 0x10)
      dst_host_rec.in_ack_cnt++;
   if (flow_rec.tcp_flags & 0x20)
      dst_host_rec.in_urg_cnt++;

   dst_host_rec.in_linkbitfield |= flow_rec.linkbitfield;
   
   flows += 1;
}

/*
int Profile::new_data(const string &timeslot, const flow_map_t &flow_map)
{
   current_timeslot = "";
   current_stat_map.clear();
   
   if (compute_host_stats(flow_map, flow_filter_func, current_stat_map) != 0) {
      current_stat_map.clear();
      log(LOG_ERR, "Error in processing of timeslot %s in profile %s.", timeslot.c_str(), name.c_str());
      return -1;
   }
   
   current_timeslot = timeslot;
   return 0;
}
*/

// Store current statistics into database
int Profile::store() const
{
   if (!current_timeslot.empty()) {
      database.store(current_timeslot, current_stat_map);
      return 0;
   }
   else {
      return -1;
   }
}

int Profile::release()
{
   current_timeslot = "";
   current_stat_map.clear();
   return 0;
}

/////////////////////////////////////////

Profile* getProfile(const std::string& name)
{
   for (unsigned int i = 0; i < profiles.size(); i++) {
      if (profiles[i]->name == name)
         return profiles[i];
   }
   return NULL;
}

