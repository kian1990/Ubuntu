#ifndef _NFSEN_H_
#define _NFSEN_H_

#include <vector>
#include <string>
#include "profile.h"

int nfsen_reader_init(const std::vector<Profile*> &profiles);

void nfsen_reader_new_data(const std::string &ts);

int nfsen_reader_cleanup();

#endif
