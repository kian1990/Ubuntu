#ifndef _SCRIPT_H
#define  _SCRIPT_H

#include <string>
#include <vector>
#include <stdint.h>
#include <sstream>


class Script {
private:
   // script path
   std::string file_path;
   
   // script argument list
   std::vector<std::string> args;
public:
   // class constructor
   Script(const std::string &file) : file_path(file) {};
   
   // template for adding paramaters
   template<typename T> 
   inline Script &operator<< (const T &value) 
   {
      std::stringstream ss;
      ss << value;
      args.push_back(ss.str());
      return *this;
   }

   // execute the script
   int execute();

   // remove all passed arguments
   void remove_args();
   
   // prints all arguments of the script -- only for debugging purposes
   void print_args();
};

#endif   /* SCRIPT_H */
