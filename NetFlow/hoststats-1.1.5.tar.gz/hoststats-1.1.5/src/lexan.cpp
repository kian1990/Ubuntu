#include <cstring>
#include <cctype>
#include <cstdio>
#include <cstdlib>

#include <string>
#include <iostream>

#include "lexan.h"

using namespace std;

enum lexan_states {
   lexan_start,
   lexan_alnum,
   lexan_num,
   lexan_only_num,
   lexan_num_end,
   lexan_e_state,
   lexan_bigger,
   lexan_smaller,
   lexan_excl,
};

bool Lexan::is_bin_op(int c)
{
   if ( (c == '+') || (c == '-') || (c == '*') || (c == '/') || (c == '>')
       || (c == '<') || (c == '=') || (c == '!') )
   {
      return true;
   }
   else
      return false;
}

void Lexan::disable()
{
   enabled = false;
}

void Lexan::enable()
{
   enabled = true;
}

int Lexan::get_token()
{
   if (enabled == false)
      return TOKEN_ERROR;

   last_token.erase();
   int state = lexan_start;

   int c = 0;

   while ( 1 ) {
      if ( index == len )
         c = EOF;
      else
         c = read_str[index];

      switch ( state ) {
      // start ----------------------------------------------------------------
      case lexan_start:
         if ( isspace(c) ) {
            index++;
            continue;
         }

         else if ( (c == '+') || (c == '-') || (c == '*') || (c == '/') || (c == '(')
         || (c == ')') || (c == '[') || (c == ']') || (c == '=') || (c == ',') )
         {
            switch ( c ) {
               case '+': last_rc = TOKEN_PLUS; break;
               case '-': last_rc = TOKEN_MINUS; break;
               case '*': last_rc = TOKEN_STAR; break;
               case '/': last_rc = TOKEN_SLASH; break;
               case '(': last_rc = TOKEN_LBRACKET; break;
               case ')': last_rc = TOKEN_RBRACKET; break;
               case '[': last_rc = TOKEN_LSBRACKET; break;
               case ']': last_rc = TOKEN_RSBRACKET; break;
               case '=': last_rc = TOKEN_EQUAL; break;
               case ',': last_rc = TOKEN_COMMA; break;
               default: last_rc = TOKEN_ERROR; break;
            }
            last_token.push_back(c);
            index++;
            token_index++;
            return last_rc;
         }

         else if ( c == EOF ) {
            last_rc = TOKEN_EOF;
            token_index++;
            return last_rc;
         }

         else if ( isalpha(c) || c == '_' ) {
            last_token.push_back(c);
            state = lexan_alnum;
            index++;
            continue;
         }

         else if ( isdigit(c) ) {
            last_token.push_back(c);
            state = lexan_num;
            index++;
            continue;
         }

         else if ( c == '>' ) {
            last_token.push_back(c);
            state = lexan_bigger;
            index++;
            continue;
         }

         else if ( c == '<' ) {
            last_token.push_back(c);
            state = lexan_smaller;
            index++;
            continue;
         }

         else if ( c == '!' ) {
            last_token.push_back(c);
            state = lexan_excl;
            index++;
            continue;
         }

         else {
            last_rc = TOKEN_ERROR;
            return last_rc;
         }
      break;

      // alnum ----------------------------------------------------------------
      case lexan_alnum:
         if ( isspace(c) || is_bin_op(c) || (c == '(') || (c == ')') || (c == '[')
         || (c == ']') || (c == ',') || (c == EOF) )
         {
            return keyword();
         }

         else if ( isalnum(c) || (c =='_') ) {
            last_token.push_back(c);
            index++;
            continue;
         }

         else {
            last_rc = TOKEN_ERROR;
            return last_rc;
         }
      break;

      // num ----------------------------------------------------------------
      case lexan_num:
         if ( isspace(c) || is_bin_op(c) || (c == ')') || (c == EOF) ) {
            last_rc = TOKEN_NUMBER;
            token_index++;
            return last_rc;
         }

         else if ( c == '.' ) {
            last_token.push_back(c);
            state = lexan_only_num;
            index++;
            continue;
         }

         else if ( c == 'e' ) {
            last_token.push_back(c);
            state = lexan_e_state;
            index++;
            continue;
         }

         else if ( isdigit(c) ) {
            last_token.push_back(c);
            index++;
            continue;
         }

         else {
            last_rc = TOKEN_ERROR;
            return last_rc;
         }
      break;

      // only_num ----------------------------------------------------------------
      case lexan_only_num:
         if ( isdigit(c) ) {
            last_token.push_back(c);
            state = lexan_num_end;
            index++;
            continue;
         }

         else {
            last_rc = TOKEN_ERROR;
            return last_rc;
         }
      break;

      // num_end ----------------------------------------------------------------
      case lexan_num_end:
         if ( isspace(c) || is_bin_op(c) || (c == ')') || (c == EOF) ) {
            last_rc = TOKEN_NUMBER;
            token_index++;
            return last_rc;
         }

         else if ( isdigit(c) ) {
            last_token.push_back(c);
            index++;
            continue;
         }

         else {
            last_rc = TOKEN_ERROR;
            return last_rc;
         }
      break;

      // e_state ----------------------------------------------------------------
      case lexan_e_state:
         if ( (c == '+') || (c == '-') ) {
            last_token.push_back(c);
            state = lexan_only_num;
            index++;
            continue;
         }

         else if ( isdigit(c) ) {
            last_token.push_back(c);
            state = lexan_num_end;
            index++;
            continue;
         }

         else {
            last_rc = TOKEN_ERROR;
            return last_rc;
         }
      break;

      // bigger ----------------------------------------------------------------
      case lexan_bigger:
         if ( c == '=' ) {
            last_token.push_back(c);
            index++;
            last_rc = TOKEN_BEQUAL;
            token_index++;
            return last_rc;
         }

         else {
            last_rc = TOKEN_BIGGER;
            token_index++;
            return last_rc;
         }
      break;

      // smaller ----------------------------------------------------------------
      case lexan_smaller:
         if ( c == '=' ) {
            last_token.push_back(c);
            index++;
            last_rc = TOKEN_SMEQUAL;
            token_index++;
            return last_rc;
         }

         else {
            last_rc = TOKEN_SMALLER;
            token_index++;
            return last_rc;
         }
      break;

      // excl ----------------------------------------------------------------
      case lexan_excl:
         if ( c == '=' ) {
            last_token.push_back(c);
            index++;
            last_rc = TOKEN_UNEQUAL;
            token_index++;
            return last_rc;
         }

         else {
            last_rc = TOKEN_ERROR;
            return last_rc;
         }
      break;

      default:
         last_rc = TOKEN_ERROR;
         return last_rc;
      }
   }

   last_rc = TOKEN_ERROR;
   return last_rc;
}

int Lexan::keyword()
{
   string kw;
   int c = last_token[0];
   int i = 1;
   while ( c != '\0' ) {
      c = toupper(c);
      kw.push_back(c);
      c = last_token[i];
      i++;
   }
   if ( kw.compare("SRC") == 0 )
      last_rc = TOKEN_SRC;
   else if ( kw.compare("DST") == 0 )
      last_rc = TOKEN_DST;
   else if ( kw.compare("IN") == 0 )
      last_rc = TOKEN_IN;
   else if ( kw.compare("OUT") == 0 )
      last_rc = TOKEN_OUT;
   else if ( kw.compare("BYTES") == 0 )
      last_rc = TOKEN_BYTES;
   else if ( kw.compare("PACKETS") == 0 )
      last_rc = TOKEN_PACKETS;
   else if ( kw.compare("FLOWS") == 0 )
      last_rc = TOKEN_FLOWS;
   else if ( kw.compare("SYN") == 0 )
      last_rc = TOKEN_SYN;
   else if ( kw.compare("FIN") == 0 )
      last_rc = TOKEN_FIN;
   else if ( kw.compare("RST") == 0 )
      last_rc = TOKEN_RST;
   else if ( kw.compare("PSH") == 0 )
      last_rc = TOKEN_PSH;
   else if ( kw.compare("URG") == 0 )
      last_rc = TOKEN_URG;
   else if ( kw.compare("ACK") == 0 )
      last_rc = TOKEN_ACK;
   else if ( kw.compare("LINKS") == 0 )
      last_rc = TOKEN_LINKS;
   else if ( kw.compare("MIN") == 0 )
      last_rc = TOKEN_MIN;
   else if ( kw.compare("MAX") == 0 )
      last_rc = TOKEN_MAX;
   else if ( kw.compare("AND") == 0 )
      last_rc = TOKEN_AND;
   else if ( kw.compare("OR") == 0 )
      last_rc = TOKEN_OR;
   else if ( kw.compare("NOT") == 0 )
      last_rc = TOKEN_NOT;
   else if ( kw.compare("FROM") == 0 )
      last_rc = TOKEN_FROM;
   else
      last_rc = TOKEN_UNKNOWN;
   token_index++;
   return last_rc;
}

/* Test main
int main()
{
   Lexan lex("out syn * 2 > in ack");
   int lex_rc = lex.get_token();

   while (lex_rc != TOKEN_EOF) {
      cout << lex_rc << " " << lex.last_token << endl;
      lex_rc = lex.get_token();
   }
   return EXIT_SUCCESS;
}
*/
