#include <cstdio>
#include <cstdlib>
#include <cerrno>
#include <cstring>
#include <stdint.h>

#include "synan.h"
#include "lexan.h"
#include "hoststats.h"

#ifdef HS_DEBUG
#define debug(...) printf(__VA_ARGS__)
#else
#define debug(...) ;
#endif

#define NULL_CHECK(ptr) do { \
   if ( ptr == NULL ) { \
      debug("!!!NULL FOUND!!!\n"); \
      errno = E_INTERNAL; \
      return EXIT_FAILURE; \
   } \
} while ( 0 )

#define CALL_CHECK(f) do { \
   if ( f == EXIT_FAILURE ) { \
      debug("!!!FUNCTION CALL FAILED!!!\n"); \
      return EXIT_FAILURE; \
   } \
} while ( 0 )

#define GET_TOKEN do { \
   if ( lex->get_token() != TOKEN_ERROR ) { \
      debug("TOKEN index: %d", lex->token_index); \
      lex->disable(); \
      debug("TOKEN: \"%s\"\n", lex->last_token.c_str()); \
   } \
} while ( 0 )

#define EOF_CHECK do { \
   GET_TOKEN; \
   if ( lex->last_rc == TOKEN_EOF ) { \
      lex->enable(); \
      debug("TOKEN recognized as an EOF\n"); \
      if ( pars == 0 ) { \
         debug("EOF FOUND\n"); \
         return EXIT_SUCCESS; \
      } \
      else { \
         debug("PARS CHECKSUM FAILED\n"); \
         errno = E_PARENTHESES; \
         return EXIT_FAILURE; \
      } \
   } \
} while ( 0 )

#define DIR_CHECK do { \
   if ( dir() == EXIT_FAILURE ) { \
      if ( errno == E_FIRST_LVL ) \
         errno = E_OK; \
      else { \
         debug("DIR FAILED\n"); \
         return EXIT_FAILURE; \
      } \
   } \
} while ( 0 )

#define OP_CHECK do { \
   if ( log_op() == EXIT_SUCCESS ) { \
      debug("CALLING stat3\n"); \
      return stat3(); \
   } \
   else { \
      if ( errno == E_FIRST_LVL ) \
         errno = E_OK; \
      else { \
         debug("OP FAILED\n"); \
         return EXIT_FAILURE; \
      } \
   } \
   debug("Calling op()\n"); \
   CALL_CHECK(op()); \
   debug("Calling op() -- NP\n"); \
   debug("CALLING stat2\n"); \
   return stat2(); \
} while ( 0 )

#define NUM_CHECK do { \
      lex->enable(); \
      debug("TOKEN recognized as a number\n"); \
      if ( current->IsFull() ) { \
         errno = E_INTERNAL; \
         return EXIT_FAILURE; \
      } \
\
      SaveData(DATA_NUM); \
} while ( 0 )

#define LBRACKET_CHECK(f) do { \
   GET_TOKEN; \
   if( lex->last_rc == TOKEN_LBRACKET ) { \
      do { \
         lex->enable(); \
         debug("TOKEN recognized as a left bracket\n"); \
         pars++; \
         (current->par_left)++; \
         if ( lex->token_index == 1 ) { \
            current->first = true; \
         } \
         GET_TOKEN; \
      } while ( lex->last_rc == TOKEN_LBRACKET ); \
      return f; \
   } \
} while ( 0 )

#define RBRACKET_CHECK(caller) do { \
   if ( bracket(caller) == EXIT_SUCCESS ) \
      return EXIT_SUCCESS; \
   else { \
      if ( errno == E_FIRST_LVL ) \
         errno = E_OK; \
      else \
         return EXIT_FAILURE; \
   } \
} while ( 0 )

#define SET_DATA(p) do { \
   if ( mode == MODE_BOTH ) \
      data = rec.in_##p + rec.out_##p; \
   else if ( mode == MODE_IN ) \
      data = rec.in_##p; \
   else if ( mode == MODE_OUT ) \
      data = rec.out_##p; \
} while ( 0 )

#define PLACE_OP do { \
   if ( current->IsFull() ) { \
      DrTreeNode *tmp = new DrTreeNode; \
      tmp->type = TYPE_OP; \
      tmp->data = lex->last_rc; \
      int insert_rc = current->Insert(tmp); \
      if ( insert_rc == INSERT_FAILED ) { \
         debug("INSERT FAILED\n"); \
         return EXIT_FAILURE; \
      } \
      else if ( insert_rc == INSERT_ROOT ) \
         if ( tree->root != NULL ) \
            tree = tree->root; \
      current = tmp; \
   } \
   else { \
      if ( current->type == TYPE_EMPTY ) { \
         current->type = TYPE_OP; \
         current->data = lex->last_rc; \
      } \
      else { \
         debug("PLACE FAILED\n"); \
         errno = E_INTERNAL; \
         return EXIT_FAILURE; \
      } \
   } \
} while ( 0 )

const int DECIMAL_BASE = 10;

enum insert_codes {
   INSERT_FAILED,
   INSERT_BRANCH,
   INSERT_ROOT
};

// Priority of operators -- subject to change
int ops_map[] = {
   0,0,0,2,2,1,1,0,0,0,0,3,3,3,3,3,3,0,4,4,4,1 //see lexan_ret enum in lexan.h
};

// D r T r e e N o d e **************************************
// P U B L I C **********************************************

int DrTreeNode::AddNewRoot(DrTreeNode *new_root)
{
   debug("AddNewRoot START\n");
   NULL_CHECK(new_root);

   if ( new_root->IsFull() ) {
      errno = E_INTERNAL;
      return EXIT_FAILURE;
   }

   // If "this" already has a root, make the roots branch point to the new_root
   if ( root != NULL ) {
      if ( root->l_ptr == this )
         root->l_ptr = new_root;

      else if ( root->r_ptr == this )
         root->r_ptr = new_root;

      else {
         errno = E_INTERNAL;
         return EXIT_FAILURE;
      }
   }

   root = new_root; // Set root of "this" to the new_root
   *(new_root->active) = this; // Set active branch of new_root to "this"
   new_root->MoveActive();

   debug("AddNewRoot END\n");
   return EXIT_SUCCESS;
}

int DrTreeNode::AddNewBranch(DrTreeNode *new_branch)
{
   debug("AddNewBranch START\n");
   NULL_CHECK(new_branch);

   if ( new_branch->IsFull() ) {
      errno = E_INTERNAL;
      return EXIT_FAILURE;
   }

   // Takes one branch out of "this", adds it into new_branch and replaces old branch with the new_branch
   if ( this->IsFull() ) {
      if ( this->r_ptr->positive == false ) { // Move negate flag from old branch to new_branch so it stays as the right operand
         new_branch->positive = false;
         this->r_ptr->positive = true;
      }
      *(new_branch->active) = this->r_ptr;

      new_branch->MoveActive();
      this->r_ptr->root = new_branch;
      this->r_ptr = new_branch;
   }

   else {
      *active = new_branch;
      MoveActive();
   }

   new_branch->root = this;

   debug("AddNewBranch END\n");
   return EXIT_SUCCESS;
}

int DrTreeNode::Copy(DrTreeNode *new_tree)
{
   NULL_CHECK(new_tree);

   memcpy(new_tree, this, sizeof(DrTreeNode));

   if ( l_ptr != NULL ) {
      new_tree->l_ptr = new DrTreeNode;
      l_ptr->Copy(new_tree->l_ptr);
   }

   if ( r_ptr != NULL ) {
      new_tree->r_ptr = new DrTreeNode;
      r_ptr->Copy(new_tree->r_ptr);
   }

   return EXIT_SUCCESS;
}

void DrTreeNode::Delete()
{
   if ( l_ptr != NULL )
      l_ptr->Delete();

   if ( r_ptr != NULL )
      r_ptr->Delete();

   if ( root != NULL ) {
      if ( root->l_ptr == this )
         root->l_ptr = NULL;

      else if ( root->r_ptr == this )
         root->r_ptr = NULL;
   }
}

int DrTreeNode::Insert(DrTreeNode *node)
{
   debug("Insert START\n");
   NULL_CHECK(node);

   bool add_root = false;
   bool off_par = true;

   int par_sum = 0;
   int inter_sum = 0;

   DrTreeNode *change = NULL;

   for (DrTreeNode *tmp = this; tmp != NULL; tmp = tmp->root) {
      if ( ( tmp->type != TYPE_OP || node->type != TYPE_OP )
          &&
         ( node->data >= (int)sizeof(ops_map) || tmp->data >= (int)sizeof(ops_map) ) )
      {
         errno = E_INTERNAL;
         return INSERT_FAILED;
      }

      inter_sum = 0 + tmp->par_right;
      if ( inter_sum > 0 ) { // Single brackets pair, e.g.: ... (syn*4) ...
         inter_sum -= tmp->par_left;
         debug("Single bracket check\n");
         if ( inter_sum <= 0 ) {
            debug("Single bracket confirmed\n");
            add_root = true;
            change = tmp;
            continue;
         }
      }

      par_sum += tmp->par_right - tmp->par_left;
      if ( par_sum > 0 ) { // Longer bracket, e.g: ... (syn*4+3...) ...
         debug("Longer bracket\n");
         off_par = false;
         add_root = true;
      }

      else if ( par_sum == 0 && !off_par && tmp->first ) { // Beginning of bracket, e.g: (syn*4...)...
         add_root = true;
         debug("Par_sum 0, !offpar, first\n");
      }

      else if ( par_sum == 0 && !off_par && !tmp->first ) {
         debug("Parsum 0, !offpar, !first\n");
         if ( ops_map[node->data] < ops_map[tmp->data] )
            break;
         else
            add_root = true;
            off_par = true;
      }

      else if ( par_sum == 0 && off_par ) { // Outside of any bracket, e.g: ...syn*4...
         debug("Parsum 0, offpar\n");
         if ( ops_map[node->data] < ops_map[tmp->data] )
            break;
         else
            add_root = true;
            off_par = true;
      }

      else if ( par_sum < 0 && off_par && tmp->first ) { // Inside of nested bracket, that starts the query
         debug("Parsum < 0, offpar, first\n");
         if ( ops_map[node->data] < ops_map[tmp->data] )
            break;
         else
            add_root = true;
      }

      else if ( par_sum < 0 && off_par && !tmp->first ) {
         debug("Parsum < 0, offpar, !first\n");
         break;
      }

      else if ( par_sum < 0 && !off_par && tmp->first ) {
         debug("Parsum < 0, !offpar, first\n");
         add_root = true;
      }

      else if ( par_sum < 0 && !off_par && !tmp->first ) {
         debug("Parsum < 0, !offpar, !first\n");
         break;
      }

      change = tmp;
   }

   if ( add_root ) {
      change->Print();
      change->AddNewRoot(node);
      debug("Insert END\n");
      return INSERT_ROOT;
   }

   else {
      this->AddNewBranch(node);
      debug("Insert END\n");
      return INSERT_BRANCH;
   }
}

bool DrTreeNode::IsFull()
{
   return full;
}

int DrTreeNode::MoveActive()
{
   debug("MoveActive START\n");
   if ( this->IsFull() )
      return EXIT_FAILURE;

   if ( *active == l_ptr )
      active = &r_ptr;

   else if ( *active == r_ptr ) {
      active = NULL;
      full = true;
   }

   debug("MoveActive END\n");
   return EXIT_SUCCESS;
}

void DrTreeNode::Negate()
{
   debug("Negate START\n");
   positive ? (positive = false) : (positive = true);
   debug("Negate END\n");
}

int DrTreeNode::Optimize()
{
   if ( l_ptr != NULL && l_ptr->type == TYPE_OP )
      l_ptr->Optimize();

   if ( r_ptr != NULL && r_ptr->type == TYPE_OP )
      r_ptr->Optimize();

   if ( l_ptr != NULL && r_ptr != NULL && l_ptr->type == TYPE_NUM && r_ptr->type == TYPE_NUM )
      return Resolve();

   return EXIT_SUCCESS;
}

void DrTreeNode::Print()
{
   debug("Data: %d\n", data);
   debug("Positive: %i\n", (int)positive);
   debug("First: %d\n", (int)first);

   if (l_ptr != NULL) {
      debug("LPTR\n");
      l_ptr->Print();
   }

   if (r_ptr != NULL) {
      debug("RPTR\n");
      r_ptr->Print();
   }
}

int DrTreeNode::Resolve()
{
   if ( l_ptr != NULL && l_ptr->type == TYPE_OP )
      CALL_CHECK(l_ptr->Resolve());

   if ( r_ptr != NULL && r_ptr->type == TYPE_OP )
      CALL_CHECK(r_ptr->Resolve());

   if ( l_ptr != NULL && r_ptr != NULL
       &&
       l_ptr->type == TYPE_NUM && r_ptr->type == TYPE_NUM && this->type == TYPE_OP )
   {
      if ( l_ptr->positive == false )
         l_ptr->data ? (l_ptr->data = false) : (l_ptr->data = true);

      if ( r_ptr->positive == false )
         r_ptr->data ? (r_ptr->data = false) : (r_ptr->data = true);

      switch ( data ) {
      case TOKEN_PLUS:
         data = l_ptr->data + r_ptr->data;
      break;

      case TOKEN_MINUS:
         data = l_ptr->data - r_ptr->data;
      break;

      case TOKEN_STAR:
         data = l_ptr->data * r_ptr->data;
      break;

      case TOKEN_SLASH:
         data = l_ptr->data / r_ptr->data;
      break;

      case TOKEN_EQUAL:
         data = ( l_ptr->data == r_ptr->data );
      break;

      case TOKEN_UNEQUAL:
         data = ( l_ptr->data != r_ptr->data );
      break;

      case TOKEN_BIGGER:
         data = ( l_ptr->data > r_ptr->data );
      break;

      case TOKEN_SMALLER:
         data = ( l_ptr->data < r_ptr->data );
      break;

      case TOKEN_SMEQUAL:
         data = ( l_ptr->data <= r_ptr->data );
      break;

      case TOKEN_BEQUAL:
         data = ( l_ptr->data >= r_ptr->data );
      break;

      case TOKEN_AND:
         data = ( l_ptr->data && r_ptr->data );
      break;

      case TOKEN_OR:
         data = ( l_ptr->data || r_ptr->data );
      break;

      case TOKEN_FROM:
         data = !( l_ptr->mask ^ r_ptr->mask );
      break;

      default:
         errno = E_INTERNAL;
         return EXIT_FAILURE;
      }

      type = TYPE_NUM;
      delete l_ptr;
      delete r_ptr;
      l_ptr = NULL;
      r_ptr = NULL;
      return EXIT_SUCCESS;
   }

   errno = E_INTERNAL;
   return EXIT_FAILURE;
}

int DrTreeNode::Update(const hosts_record_t &rec)
{
   if ( l_ptr != NULL )
      CALL_CHECK(l_ptr->Update(rec));

   if ( r_ptr != NULL )
      CALL_CHECK(r_ptr->Update(rec));

   if ( type == TYPE_ITEM ) {
      switch ( data ) {
      case TOKEN_FLOWS:
         SET_DATA(flows);
      break;

      case TOKEN_PACKETS:
         SET_DATA(packets);
      break;

      case TOKEN_BYTES:
         SET_DATA(bytes);
      break;

      case TOKEN_SYN:
         SET_DATA(syn_cnt);
      break;
      case TOKEN_ACK:
         SET_DATA(ack_cnt);
      break;

      case TOKEN_FIN:
         SET_DATA(fin_cnt);
      break;

      case TOKEN_RST:
         SET_DATA(rst_cnt);
      break;

      case TOKEN_PSH:
         SET_DATA(psh_cnt);
      break;

      case TOKEN_URG:
         SET_DATA(urg_cnt);
      break;

      case TOKEN_LINKS:
         SET_DATA(linkbitfield);
      break;

      default:
         errno = E_INTERNAL;
         return EXIT_FAILURE;
      }

      type = TYPE_NUM;
   }
   return EXIT_SUCCESS;
}

// S y n a n ************************************************
// P R O T E C T E D ****************************************

int Synan::stat()
{
   debug("stat START\n");

   // <stat> -> ( <stat>
   LBRACKET_CHECK(stat());

   // <stat> -> number ...
   GET_TOKEN;
   if ( lex->last_rc == TOKEN_NUMBER ) {
      NUM_CHECK;

      // <stat> -> number <bracket>
      RBRACKET_CHECK(CALLER_STAT);

      // <stat> -> number <op> <stat2>
      debug("Calling op()\n");
      CALL_CHECK(op());
      debug("Calling op() -- NP\n");

      debug("stat END\n");
      return stat2();
   }

   // <stat> -> <dir> ...
   DIR_CHECK;

   // <stat> -> <item> ...
   debug("Calling item()\n");
   CALL_CHECK(item());
   debug("Calling item() -- NP\n");

   // <stat> -> <item> <bracket>
   RBRACKET_CHECK(CALLER_STAT);

   // <stat> -> <item> <op> <stat2>
   debug("Calling op()\n");
   CALL_CHECK(op());
   debug("Calling op() -- NP\n");

   debug("stat END\n");
   return stat2();
}

int Synan::stat2()
{
   debug("stat2 START\n");
   // <stat2> -> ( <stat2>
   LBRACKET_CHECK(stat2());

   // <stat2> -> <bracket>
   RBRACKET_CHECK(CALLER_STAT2);

   // <stat2> -> number ...
   GET_TOKEN;
   if ( lex->last_rc == TOKEN_NUMBER ) {
      NUM_CHECK;

      // <stat2> -> number EOF
      EOF_CHECK;

      // <stat2> -> number <bracket>
      RBRACKET_CHECK(CALLER_STAT2);

      //<stat2> -> number <log-op> <stat3>
      //<stat2> -> number <op> <stat2>
      OP_CHECK;
   }

   // <stat2> -> <dir> ...
   DIR_CHECK;

   // <stat2> -> <item> ...
   debug("Calling item()\n");
   CALL_CHECK(item());
   debug("Calling item() -- NP\n");

   // <stat2> -> <item> EOF
   EOF_CHECK;

   // <stat2> -> <item> <bracket>
   RBRACKET_CHECK(CALLER_STAT2);

   //<stat2> -> <item> <log-op> <stat3>
   //<stat2> -> <item> <op> <stat2>
   OP_CHECK;
}

int Synan::stat3()
{
    debug("stat3 START\n");
   // <stat3> -> ( <stat2>
   LBRACKET_CHECK(stat2());

   // <stat3> -> <dir> ...
   DIR_CHECK;

   // <stat3> -> <item> <op> <stat2>
   if ( item() == EXIT_SUCCESS ) {
      debug("Calling op()\n");
      CALL_CHECK(op());
      debug("Calling op() -- NP\n");

      debug("stat3 END\n");
      return stat2();
   }
   else {
      if ( errno == E_FIRST_LVL )
         errno = E_OK;
      else
         return EXIT_FAILURE;
   }

   // <stat3> -> <links> ...
   debug("Calling links()\n");
   CALL_CHECK(links());
   debug("Calling links() -- NP\n");

   // <stat3> -> <links> EOF
   EOF_CHECK;

   // <stat3> -> <links> <log-op> <stat3>
   debug("Calling log_op()\n");
   CALL_CHECK(log_op());
   debug("Calling log_op() -- NP\n");

   debug("stat3 END\n");
   return stat3();
}

int Synan::bracket(int caller)
{
   debug("bracket START\n");
   GET_TOKEN;
   if ( lex->last_rc == TOKEN_RBRACKET ) {
      do {
         lex->enable();
         debug("TOKEN recognized as a right bracket\n");
         if ( pars > 0 ) {
            pars--;
            (current->par_right)++;
         }
         else {
            errno = E_PARENTHESES;
            return EXIT_FAILURE;
         }
         GET_TOKEN;
      } while ( lex->last_rc == TOKEN_RBRACKET );

      if ( caller == CALLER_STAT ) {
         // <bracket> -> ) <op> <stat2>
         debug("Calling op()\n");
         CALL_CHECK(op());
         debug("Calling op() -- NP\n");

         debug("bracket END\n");
         debug("CALLING stat2\n");
         return stat2();
      }

      else if ( caller == CALLER_STAT2 ) {
         // <bracket> -> ) EOF
         EOF_CHECK;

         // <bracket> -> ) <log-op> <stat3>
         // <bracket> -> ) <op> <stat2>
         OP_CHECK;
      }
   }
   else {
      errno = E_FIRST_LVL;
      return EXIT_FAILURE;
   }
   return EXIT_SUCCESS;
}

int Synan::dir()
{
   debug("dir START\n");
   GET_TOKEN;
   if ( lex->last_rc == TOKEN_IN ) {
      lex->enable();
      debug("TOKEN recognized as a direction IN\n");
      mode = MODE_IN;
      debug("dir END\n");
      return EXIT_SUCCESS;
   }
   else if ( lex->last_rc == TOKEN_OUT ) {
      lex->enable();
      debug("TOKEN recognized as a direction OUT");
      mode = MODE_OUT;
      debug("dir END\n");
      return EXIT_SUCCESS;
   }

   errno = E_FIRST_LVL;
   return EXIT_FAILURE;
}

int Synan::item()
{
   debug("item START\n");
   GET_TOKEN;
   switch ( lex->last_rc ) {
   case TOKEN_FLOWS:
   case TOKEN_PACKETS:
   case TOKEN_BYTES:
   case TOKEN_SYN:
   case TOKEN_ACK:
   case TOKEN_FIN:
   case TOKEN_RST:
   case TOKEN_PSH:
   case TOKEN_URG:
      lex->enable();
      debug("TOKEN recognized as on of the keywords FLOWS/PACKETS/BYTES/SYN/ACK/FIN/RST/PSH/URG\n");
      if ( current->IsFull() ) {
         errno = E_INTERNAL;
         return EXIT_FAILURE;
      }

      else {
         SaveData(DATA_ITEM);
         mode = MODE_BOTH; // default mode prepared for next item
      }
   break;

   default:
      errno = E_FIRST_LVL;
      return EXIT_FAILURE;
   }

   debug("item END\n");
   return EXIT_SUCCESS;
}

int Synan::op()
{
   debug("op START\n");
   GET_TOKEN;
   switch ( lex->last_rc ) {
   case TOKEN_BIGGER:
   case TOKEN_SMALLER:
   case TOKEN_EQUAL:
   case TOKEN_UNEQUAL:
   case TOKEN_BEQUAL:
   case TOKEN_SMEQUAL:
   case TOKEN_PLUS:
   case TOKEN_MINUS:
   case TOKEN_STAR:
   case TOKEN_SLASH:
      lex->enable();
      debug("TOKEN recognized as one of the operators >,<,=,!=,>=,<=,+,-,*,/\n");
      PLACE_OP;
   break;

   default:
      errno = E_FIRST_LVL;
      return EXIT_FAILURE;
   }

   debug("op END\n");
   return EXIT_SUCCESS;
}

int Synan::log_op()
{
   debug("log_op START\n");
   GET_TOKEN;
   switch ( lex->last_rc ) {
   case TOKEN_AND:
   case TOKEN_OR:
      lex->enable();
      debug("TOKEN recognized as one of the operators AND/OR\n");
      PLACE_OP;
      GET_TOKEN;
      if ( lex->last_rc == TOKEN_NOT ) {
         lex->enable();
         debug("TOKEN recognized as NOT operator\n");
         if ( *(current->active) == NULL )
            *(current->active) = new DrTreeNode;
         (*(current->active))->Negate();
      }
   break;
   default:
      errno = E_FIRST_LVL;
      return EXIT_FAILURE;
   }

   debug("log_op END\n");
   return EXIT_SUCCESS;
}

int Synan::links()
{
   GET_TOKEN;
   if ( lex->last_rc == TOKEN_FROM ) {
      lex->enable();
      debug("TOKEN recognized as FROM operator.\n");
      PLACE_OP;
      GET_TOKEN;
      if ( lex->last_rc == TOKEN_LINKS ) {
         lex->enable();
         SaveData(TYPE_ITEM);
         GET_TOKEN;
         if ( lex->last_rc == TOKEN_LSBRACKET ) {
            lex->enable();
            debug("Calling link_item()\n");
            CALL_CHECK(link_item());
            debug("Calling link_item() -- NP\n");
            return link_list();
         }
      }

      errno = E_SYNTACTIC_ERROR;
      return EXIT_FAILURE;
   }

   else {
      errno = E_FIRST_LVL;
      return EXIT_FAILURE;
   }
}

int Synan::link_list()
{
   GET_TOKEN;
   if ( lex->last_rc == TOKEN_RSBRACKET ) {
      lex->enable();
      debug("TOKEN recognized as a right square bracket\n");
      return EXIT_SUCCESS;
   }

   else if ( lex->last_rc == TOKEN_COMMA ) {
      lex->enable();
      debug("TOKEN recognized as a comma\n");
      GET_TOKEN;
      debug("Calling link_item()\n");
      CALL_CHECK(link_item());
      debug("Calling link_item() -- NP\n");

      GET_TOKEN;
      return link_list();
   }

   return EXIT_FAILURE;
}

int Synan::link_item()
{
   GET_TOKEN;
   if ( lex->last_rc == TOKEN_UNKNOWN ) {
      bool match_found = false;
      uint64_t bit_mask = 0x1;

      for ( unsigned int i = 0; i < source_names.size(); i++ ) {
         if ( source_names[i].compare(lex->last_token) == 0 ) {
            bit_mask = 0x1 << i;
            if ( *(current->active) == NULL )
               *(current->active) = new DrTreeNode;
            (*(current->active))->mask = (*(current->active))->mask | bit_mask;
            match_found = true;
         }
      }

      if ( match_found == false ) {
         errno = E_SYNTACTIC_ERROR;
         return EXIT_FAILURE;
      }
   }
   return EXIT_FAILURE;
}

int Synan::SaveData(int data_type)
{
   DrTreeNode *tmp = NULL;
   if ( *(current->active) == NULL ) {
      tmp = new DrTreeNode;
      *(current->active) = tmp;
   }
   else
      tmp = *(current->active);

   if ( data_type == DATA_NUM ) {
      if ( lex->last_token.find("e") != string::npos || lex->last_token.find(".") != string::npos ) {
         double number = strtod(lex->last_token.c_str(), NULL);
         tmp->data = number;
      }
      else {
         int number = strtol(lex->last_token.c_str(), NULL, DECIMAL_BASE);
         tmp->data = number;
      }
      tmp->type = TYPE_NUM;
   }

   else if ( data_type == DATA_ITEM ) {
      tmp->type = TYPE_ITEM;
      tmp->data = lex->last_rc;
      tmp->mode = mode;
   }

   else {
      errno = E_INTERNAL;
      return EXIT_FAILURE;
   }

   current->MoveActive();
   return EXIT_SUCCESS;
}

// S y n a n ************************************************
// P U B L I C **********************************************

int Synan::Execute(const stat_map_t &in_stat_map, vector<pair<hosts_key_t, hosts_record_t> > &out_stat_map)
{
   CALL_CHECK(stat());

   debug("TREE -------------------\n");
   tree->Print();

   tree->Optimize();

   DrTreeNode *tmp = new DrTreeNode;
   out_stat_map.clear();

   for ( stat_map_citer it = in_stat_map.begin(); it != in_stat_map.end(); it++ ) {
      tree->Copy(tmp);

      tmp->Update(it->second);

      tmp->Resolve();

      if ( tmp->data )
         out_stat_map.push_back(make_pair(it->first, it->second));
   }

   delete tmp;
   return EXIT_SUCCESS;
}
