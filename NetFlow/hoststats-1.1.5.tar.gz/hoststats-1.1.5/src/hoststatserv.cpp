#include <sys/select.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <ctype.h>
#include <err.h>
#include <netdb.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <iostream>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <pthread.h>
#include <string>
#include <sstream>
#include <regex.h>

#include "hoststats.h"
#include "aux_func.h"
//#include "processdata.h"
#include "nfsen.h"
#include "configuration.h"
#include "requesthandlers.h"
#include "profile.h"
//#include "sshdetection.h"

#define BUFFER    (1024)

#define HASHMAPSIZE 100000
#define SHMSZ    1000

using namespace std;

////////////////////////////
// Global variables

bool background = false;  // Run in background
int log_syslog = true;   // Log into syslog
int log_upto = LOG_INFO; // Log up to level 

vector<string> source_names;

////////////////////////////
// Module global variables

static int running_threads = 0; // Number of running child threads
static pthread_mutex_t running_mutex = PTHREAD_MUTEX_INITIALIZER;

static bool do_background = false;  // Whether se shoud go to background

///////////////////////////////////////////////////
// Flow filter functions for profile definitions
/*
// SSH (TCP port 22)
bool ff_ssh(const flow_key_t& key, const flow_record_t& rec)
{
   return (key.proto == 6 && (key.sport == 22 || key.dport == 22));
}

// Telnet (TCP port 23)
bool ff_telnet(const flow_key_t& key, const flow_record_t& rec)
{
   return (key.proto == 6 && (key.sport == 23 || key.dport == 23));
}

// DNS (TCP and UDP ports 53)
bool ff_dns(const flow_key_t& key, const flow_record_t& rec)
{
   return ((key.proto == 6 || key.proto == 17) && (key.sport == 53 || key.dport == 53));
}
*/

///////////////////////////////////////////////////////////////////////////////

/**
 * Thread function
 */
void *service(void * connectfd)
{
   ssize_t n, r;
   char buf[BUFFER];
   string params;
   int fd = * ((int *) connectfd);
   int action = -1;
   bool stop = false;
   
   // Read null-terminated message from socket
   while ( !stop && (n = read(fd, buf, BUFFER)) > 0) {
      r = 0;
      if (action == -1 && n > 0) {
         action = (unsigned char)buf[0];
         r = 1;
         //log(LOG_INFO, "Trap action %i", action);
      }
      while (r < n && buf[r] != 0) {
         params += buf[r];
         r++;
      }
      stop = (buf[r] == 0);
   }
   
   // Message about new data available
   if (action == NEW_DATA) {
      log(LOG_INFO, "NEW_DATA received (timeslot: %s).", params.c_str());
      nfsen_reader_new_data(params);
   }
   // Request from frontend
   else if (action < num_request_handlers && request_handlers[action] != 0) {
      log(LOG_DEBUG, "Request received (code: %i, params: \"%s\").", action, params.c_str());
      string ret = request_handlers[action](params);
      r = write(fd, ret.c_str(), ret.length());
      if (r == (ssize_t) -1)
         log(LOG_ERR, "Could not write reply, error status: %i", errno);
      if (r != (ssize_t) ret.length())
         log(LOG_ERR, "write(): Buffer written just partially");
      log(LOG_DEBUG, "Request %i replied.", action);
   }
   else {
      log(LOG_ERR, "Unknown request (code %i) received.", action);
   }
   close(fd);
   
   pthread_mutex_lock(&running_mutex);
   running_threads--;
   pthread_mutex_unlock(&running_mutex);
   pthread_exit(NULL);
}

void print_help(void)
{
   printf("hoststatserv\n");
   printf("=========\n");
   printf("Listens on network interface and processes requests for host statistics.\n");
   printf("\n");
   printf("Usage:\n");
   printf(" ./hoststatserv OPTIONS\n");
   printf("    -h             Print help\n");
   printf("    -d             Daemonize (run in background)\n");
   printf("    -c FILE        Load configuration from file.\n");
   printf("\n");
   exit(EXIT_SUCCESS);
}


int arguments(int argc, char *argv[])
{
   int opt;
   
   while ((opt = getopt(argc, argv, "hdc:")) != -1) {
      switch (opt) {
      case 'h':  // help
         print_help();
         break;
      case 'd':  // daemonize/background
         do_background = true;
         break;
      case 'c':  // load used defined configuration file
         Configuration::setConfigurationFile(string(optarg));
         break;
      default:  // invalid arguments
         fprintf(stderr,"Invalid arguments\n");
         exit(1);
      }
   }
   return 1;
}

static int terminated = 0;

void parse_logmask(string &mask);

void terminate_daemon(int signal)
{
//    Configuration *cf;
   string logmask;

   switch (signal) {
//    case SIGHUP:
//       syslog(LOG_NOTICE, "Cought HUP signal -> reload configuration...");
//       cf = Configuration::getInstance();
//       cf->reload();
//       logmask = cf->getValue("log-upto-level");
//       parse_logmask(logmask);
//       break;
   case SIGTERM:
      terminated = 1;
      log(LOG_NOTICE, "Cought TERM signal...");
      break;
   case SIGINT:
      terminated = 1;
      log(LOG_NOTICE, "Cought INT signal...");
      break;
   default:
      break;
   }
}

void parse_logmask(string &mask)
{
   if (mask.compare("LOG_EMERG") == 0) {
      log_upto = LOG_EMERG;
   } else if (mask.compare("LOG_ALERT") == 0) {
      log_upto = LOG_ALERT;
   } else if (mask.compare("LOG_CRIT") == 0) {
      log_upto = LOG_CRIT;
   } else if (mask.compare("LOG_ERR") == 0) {
      log_upto = LOG_ERR;
   } else if (mask.compare("LOG_WARNING") ==0) {
      log_upto = LOG_WARNING;
   } else if (mask.compare("LOG_NOTICE") == 0) {
      log_upto = LOG_NOTICE;
   } else if (mask.compare("LOG_INFO") == 0) {
      log_upto = LOG_INFO;
   } else if (mask.compare("LOG_DEBUG") == 0) {
      log_upto = LOG_DEBUG;
   }
   setlogmask(LOG_UPTO(log_upto));
}

int main(int argc, char *argv[])
{
   string basedir;
   int ret_code = 1; // Application return code
   bool hoststats_started_printed = false;
   string db_path, db_ro_str;
   bool db_read_only;
   
   int socket_fd, connection_fd;
   struct sockaddr_un address;
   
   openlog(NULL, LOG_NDELAY, 0);
   
   // Default configuration may be overwritten by arguments
   arguments(argc, argv);

   // Initialize Configuration singleton
   Configuration *config = Configuration::getInstance();
   if (!config->isOk()) {
   	log(LOG_ERR, "ERROR: Could not load configuration.");
   	return -1;
   }
   
   // Load default configuration from config file
   config->lock();
   
   basedir = config->getValue("basedir");
   if (basedir.empty()) {
      log(LOG_ERR, "ERROR: 'basedir' not found in configuration file.");
   }
   if (basedir[basedir.size()-1] != '/')
      basedir += '/';
   


   signal(SIGTERM, terminate_daemon);
   signal(SIGINT, terminate_daemon);
   /* reload configuration signal: */
   //signal(SIGHUP, terminate_daemon);

   /* Set logmask if used */
   string logmask = config->getValue("log-upto-level");
   if (!logmask.empty()) {
      parse_logmask(logmask);
   }
   
   // ***** Read source names *****
   
   // Split sources_str by ','
   string sources_str = config->getValue("flow-sources");
   source_names = split(sources_str, ',');
   for (unsigned int i = 0; i < source_names.size(); i++) {
      size_t pos = source_names[i].find(':');
      string name = source_names[i].substr(0, pos);
      string color = pos != string::npos ? source_names[i].substr(pos + 1) : "";
              
      // Trim each source name
      source_names[i] = trim(name);
      if (source_names[i].empty()) {
         log(LOG_ERR, "ERROR: Invalid sources specifier in configuration.");
         return -1;
      }
      
      // Check the color of flow-source
      if (pos != string::npos) {
         if ((color.size() != 3 && color.size() != 6) || 
                 color.find_first_not_of("0123456789ABCDEFabcdef") != string::npos) {
            log(LOG_ERR, "ERROR: invalid color '%s' of flow-source '%s' in "
               "configuration file.", color.c_str(), name.c_str());
            return -1;
         }
      } else {
         log(LOG_WARNING, "WARNING: Color of flow-source '%s' is not specified.", name.c_str());
      }
   }
   if (source_names.empty()) {
      log(LOG_ERR, "ERROR: 'flow-sources' not found in configuration file.");
      return -1;
   }
   
   // ***** Create profiles *****
   
   // Prepare regular expression to check "max-size" parameter
   regex_t re_max_size;
   if (regcomp(&re_max_size, "^[0-9]+[KMGTkmgt]?B?$", REG_NOSUB | REG_EXTENDED) != 0) {
      log(LOG_ERR, "ERROR (file: %s, line: %s", __FILE__, __LINE__);
      return -1;
   }
   
   // Load profiles and their filters from configration
   string profile_names_str = config->getValue("profiles");
   if (profile_names_str.empty()) {
      log(LOG_ERR, "ERROR: 'profiles' not found in configuration file.");
      return -1;
   }
   vector<string> profile_names = split(profile_names_str, ',');
   // For each profile...
   for (unsigned int i = 0; i < profile_names.size(); i++) {
      // Check name of profile
      string name = trim(profile_names[i]);
      if (name.empty()) {
         log(LOG_ERR, "ERROR: invalid specification of profile names in configuration file.");
         goto exit3;
      }
      // Get filter
      string filter = config->getValue(name+":filter");
      // Get max-size and check it
      string max_size = config->getValue(name+":max-size");
      if (max_size.empty()) {
         log(LOG_WARNING, "WARNING: Maximum size of profile '%s' is not specified. Using '%s' as default.", name.c_str(), DEFAULT_PROFILE_MAX_SIZE);
         max_size = DEFAULT_PROFILE_MAX_SIZE;
      }
      if (regexec(&re_max_size, max_size.c_str(), 0, NULL, 0) == REG_NOMATCH) {
         log(LOG_ERR, "ERROR: invalid 'max-size' in profile '%s'.", max_size.c_str());
         goto exit3;
      }
      // Get color and check it
      string color = config->getValue(name+":color");
      if (color.empty()) {
         log(LOG_WARNING, "WARNING: Color of profile '%s' is not specified.", name.c_str());
      } else {
         // Valid format of color: RGB or RRGGBB
         if ((color.size() != 3 && color.size() != 6) || 
                 color.find_first_not_of("0123456789ABCDEFabcdef") != string::npos) {
            log(LOG_ERR, "ERROR: invalid color '%s' of profile '%s' in configuration file.", color.c_str(), name.c_str());
            goto exit3;
         }
      }

      // Create the profile and add it to list of profiles
      profiles.push_back(new Profile(name, filter, max_size, color));
   }
   
   // ***** Initialize nfsen reader *****
   if (nfsen_reader_init(profiles) != 0) {
      // Error message was already written by nfsen_reader_init.
      goto exit3;
   }
   
   // ***** Connect profile databases *****
   
   // Get database related parameters from config
   db_path = config->getValue("db-path");
   if (db_path.empty()) {
      log(LOG_ERR, "ERROR: 'db-path' not set in configuration file.");
      goto exit2;
   }
   db_ro_str = config->getValue("db-read-only");
   db_read_only = false;
   if (db_ro_str == "1" || db_ro_str == "true" || db_ro_str == "yes") {
      log(LOG_NOTICE, "Database is in read-only mode - no data will be stored.");
      db_read_only = true;
   }
   Database::db_cleaner = config->getValue("db-cleaner");
   if (Database::db_cleaner.empty()) {
      log(LOG_WARNING, "WARNING: Script for database cleanup is not set.");
   }
   
   config->unlock();
   
   // Connect databases
   for (unsigned int i = 0; i < profiles.size(); i++) {
      if (profiles[i]->database.connect(db_path, db_read_only) != 0) {
         log(LOG_ERR, "ERROR: Initialization of database for profile '%s' failed.", profiles[i]->name.c_str());
         goto exit2;
      }
   } 
   

   // ***** Prepare server *****
   {
      // Create socket
      socket_fd = socket(PF_UNIX, SOCK_STREAM, 0);
      if (socket_fd < 0) {
         log(LOG_ERR, "ERROR: socket() failed: %s\n", strerror(errno));
         goto exit2;
      }
      
      // set up address structure
      string socket_file = basedir + "comm.sock";
      if (socket_file.size() >= sizeof(address.sun_path)-1) {
         log(LOG_ERR, "ERROR: Socket file name too long. Max length: %i, file name: '%s'", sizeof(address.sun_path)-1, socket_file.c_str());
         goto exit2;
      }
      memset(&address, 0, sizeof(struct sockaddr_un));
      address.sun_family = AF_UNIX;
      strcpy(address.sun_path, socket_file.c_str());
   
      unlink(address.sun_path); // remove socket file if already exists
      
      // bind socket
      if (bind(socket_fd, (struct sockaddr*)&address, sizeof(struct sockaddr_un)) != 0) {
         log(LOG_ERR, "ERROR: bind() failed: %s\n", strerror(errno));
         goto exit2;
      }
      
      // set permissions on the socket file (read and write for all)
      chmod(address.sun_path, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH);
   
      // listen
      if(listen(socket_fd, 5) != 0) {
         log(LOG_ERR, "ERROR: listen() failed: %s\n", strerror(errno));
         goto exit1;
      }
   }
   
   // ***** Initialization done, switch to background (daemonize) *****
   
   log(LOG_NOTICE, "HostStats started");
   hoststats_started_printed = true;
   
   if (do_background) {
      log(LOG_INFO, "Entering daemon mode");
      
      int pid = fork();
      if (pid == 0) {
         // child
         // create new session
         setsid();
         
         // Store PID into pid-file
         int pid = getpid();
         string pidfilename = basedir+"hoststats.pid";
         FILE *pidfile = fopen(pidfilename.c_str(), "w");
         if (!pidfile) {
            log(LOG_ERR, "ERROR: Can't create PID file '%s'. Exitting.", pidfilename.c_str());
            goto exit1;
         }
         fprintf(pidfile, "%i", pid);
         fclose(pidfile);
         
         background = true;
         
         // Deamonize
         // redirect stdin, stdout and stderr to /dev/null
         close(0);
         close(1);
         close(2);
         if (open("/dev/null", O_RDWR) != 0) {
             log(LOG_ERR, "Unable to open /dev/null: %s", strerror(errno));
             ret_code = 1;
             goto exit1;
         }
         dup(0);
         dup(0);
      } else if (pid > 0) {
         // parent process - close immediately
         return 0;
      } else {
         log(LOG_ERR, "fork failed");
         ret_code = 1;
         goto exit1;
      } 
   }

   // ***** Start accepting requests *****
   while (!terminated) {
      fd_set rset;
      FD_ZERO(&rset);
      FD_SET(socket_fd, &rset);
      // Wait for new connection
      log(LOG_DEBUG, "Waiting for requests ...");
      if (select(socket_fd+1, &rset, NULL, NULL, NULL) == -1) {
         if (errno != EINTR)
            log(LOG_NOTICE, "Select() - %s", strerror(errno));
         continue;
      }
      if (!FD_ISSET(socket_fd, &rset)) {
         continue;
      }
      
      // Accept new connection
      connection_fd = accept(socket_fd, NULL, NULL);
      if (connection_fd < 0) {
         log(LOG_ERR, "ERROR: accept() failed: %s\n", strerror(errno));
         break;
      }
      // Create service thread
      pthread_mutex_lock(&running_mutex);
      running_threads++;
      pthread_mutex_unlock(&running_mutex);
      pthread_t servicethread;
      int ret = pthread_create(&servicethread, NULL, &service, (void *) &connection_fd);
      pthread_detach(servicethread);
      if (ret) {
         log(LOG_ERR, "ERROR: pthread_create() failed: %s", strerror(ret));
         pthread_mutex_lock(&running_mutex);
         running_threads--;
         pthread_mutex_unlock(&running_mutex);
         close(socket_fd);
         break;
      }
   }
   
   // ***** Server part end, do cleanup and exit *****
   

   log(LOG_INFO, "Exiting...");
   ret_code = 0; // set application return code to 0 (no error)
   
exit1:
   
   close(socket_fd);
   
   // Wait until all service threads finish
   if (running_threads > 0) {
      log(LOG_INFO, "Waiting for service threads to finish ...");
      while (running_threads > 0) {
         sleep(1);
      }
   }
   
exit2:
   nfsen_reader_cleanup();

exit3:
   // Delete profiles
   for (unsigned int i = 0; i < profiles.size(); i++) {
      delete profiles[i];
   }

   // Remove pid file
   if (background) {
      string pidfilename = basedir+"hoststats.pid";
      unlink(pidfilename.c_str());
   }
   
   if (hoststats_started_printed)
      log(LOG_NOTICE, "HostStats stopped.");
   
   return ret_code;
}
