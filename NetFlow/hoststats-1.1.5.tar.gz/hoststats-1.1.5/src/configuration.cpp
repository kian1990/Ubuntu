/*!
 * \file configuration.cpp
 * \brief The Configuration singleton - used for centralized access to configuration
 * \author Tomas Cejka <cejkat@cesnet.cz>
 * \date 2013
 * \date 2012
 */
/*
 * Copyright (C) 2013 CESNET
 *
 * LICENSE TERMS
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Neither the name of the Company nor the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * ALTERNATIVELY, provided that this notice is retained in full, this
 * product may be distributed under the terms of the GNU General Public
 * License (GPL) version 2 or later, in which case the provisions
 * of the GPL apply INSTEAD OF those given above.
 *
 * This software is provided ``as is'', and any express or implied
 * warranties, including, but not limited to, the implied warranties of
 * merchantability and fitness for a particular purpose are disclaimed.
 * In no event shall the company or contributors be liable for any
 * direct, indirect, incidental, special, exemplary, or consequential
 * damages (including, but not limited to, procurement of substitute
 * goods or services; loss of use, data, or profits; or business
 * interruption) however caused and on any theory of liability, whether
 * in contract, strict liability, or tort (including negligence or
 * otherwise) arising in any way out of the use of this software, even
 * if advised of the possibility of such damage.
 *
 */
#include <iostream>
#include <fstream>
#include <map>
#include <string>
#include <syslog.h>
#include <pthread.h>
#include "aux_func.h"
#include "configuration.h"

using namespace std;


bool copy_file(const char* from, const char* to)
{
   ifstream src(from);
   if (!src.good()) {
      src.close();
      return false;
   }
   ofstream dst(to);
   if (!dst.good()) {
      src.close();
      dst.close();
      return false;
   }
   dst << src.rdbuf();
   if (!dst.good()) {
      src.close();
      dst.close();
      return false;
   }
   src.close();
   dst.close();
   return true;
}


bool Configuration::parseLine(string line)
{
   string paramName, value;

   size_t pos = line.find_first_of(INI_DELIM);
   if (pos == string::npos) {
      /* not found - skip? */
      return true;
   }

   if (trim(line.substr(pos + 1)).empty()) {
      /* nothing after delimeter */
      cerr << "Line in configuration file '" << line <<
              "': nothing after symbol '" << INI_DELIM << "'." << endl;
      return false;
   }
   
   paramName = trim(line.substr(0, pos));
   value = trim(line.substr(pos+1));
   values[paramName] = value;
   return true;
}

bool Configuration::load_file(const string &filename)
{
   fstream file;
   string line, tmp;
   size_t pos;
   
   file.open(filename.c_str(), ios_base::in);
   if (!file.good())
      return false;
      
   do {
      getline(file, tmp);
      // Trim comment (everything after "#")
      if ((pos = tmp.find('#')) != string::npos) {
         if (pos == 0) // If everything is commened, skip the line
            continue;
         tmp = tmp.substr(0, pos);
      }
      // If line ends with '\' join it with the next line
      if (!tmp.empty() && tmp[tmp.size()-1] == '\\') {
         line += tmp.substr(0, tmp.size()-2);
         continue;
      }
      line += tmp;
      // Parse the line
      if (!line.empty() && !parseLine(line)) {
         // Parse line failed
         file.close();
         return false;
      }
      line.erase();
   } while (file.good());
   file.close();
   return true;
}


Configuration::Status Configuration::load()
{
   if (config_file_path.size()) {
      if (load_file(config_file_path)) {
   	   return INIT_OK;
      }

      cerr << "Could not load configuration file \"" << config_file_path << "\"" << endl;
      return INIT_FAILED;
   }

   if (load_file(INI_FILENAME))
      return INIT_OK;
   if (load_file("/etc/" INI_FILENAME))
      return INIT_OK;
   
   // Config file is not in current directory nor in /etc/
   cerr << "Could not load configuration file \"" << INI_FILENAME << "\"" << endl;
   return INIT_FAILED;
}

Configuration::Configuration()
{
   pthread_mutex_init(&config_mutex, NULL);
   init_status = load();
}

int Configuration::lock()
{
   return pthread_mutex_lock(&config_mutex);
}

int Configuration::unlock()
{
   return pthread_mutex_unlock(&config_mutex);
}

void Configuration::reload()
{
   lock();
   clean();
   init_status = load();
   unlock();
}

string Configuration::getValue(string paramName)
{
   return values[paramName];
}

Configuration *Configuration::getInstance()
{
   // Only allow one instance of class to be generated.
   if (!Configuration::instance) {
      instance = new Configuration();
   }

   return instance;
}

void Configuration::clean()
{
   /* should be already locked, do not try to lock again */
   values.clear();
}

// Used for testing
void Configuration::dump()
{
   map<string, string>::const_iterator it = values.begin();
   while (it != values.end()) {
      cout << it->first << "=\"" << it->second << '"' << endl;
      it++;
   }
}

void Configuration::freeConfiguration()
{
   if (instance)
      delete instance;
   instance = NULL;
   pthread_mutex_destroy(&config_mutex);
   /* This class is useless from this time! */
}

void Configuration::setConfigurationFile(const string &path)
{
   config_file_path = path;
}

bool Configuration::isOk()
{
   if (init_status != INIT_OK) {
      return false;
   }

	return true;
}

Configuration *Configuration::instance = NULL;
pthread_mutex_t Configuration::config_mutex;
Configuration::Status Configuration::init_status = NOT_INIT;
string Configuration::config_file_path = "";

#ifdef DEBUG_HS_CONFIG
bool background;
int log_syslog;
int log_upto;

int main(int argc, char **argv)
{
   Configuration::getInstance()->dump();
//    cout << "Found value: " << Configuration::getInstance()->getValue("rules") << endl;
//    cout << "Found value: " << Configuration::getInstance()->getValue("rles") << endl;

   return 0;
}
#endif
