#ifndef _PROFILE_H_
#define _PROFILE_H_

#include "hoststats.h"
#include "database.h"
#include "BloomFilter.hpp"
#include <string>
#include <vector>

#define DEFAULT_PROFILE_MAX_SIZE "10GB"

class Profile {
   //flow_filter_func_ptr flow_filter_func;
public:
   std::string name;
   std::string desc;
   std::string color;
   std::string filter;
   Database database;
   std::string current_timeslot;
   stat_map_t current_stat_map;
   bloom_filter bfilter;
   unsigned long flows;
   bool too_much_hosts_error_printed;
   
   // Constructor
   Profile(const std::string &name, const std::string& filter,
           const std::string& max_size, const std::string color = "",
           const std::string &desc = "");
   
   // Destructor
   ~Profile();
   
   // Do what is needed after configuration is reloaded
   //int reload_config();
   
   // Include flow record into the profile statistics
   void put_flow(const flow_key_t &key, const flow_record_t &rec);
   
   // Release current stats from memory and prepare for receival of data of next timeslot
   void new_timeslot(const std::string &timeslot);
   
   // Compute host stats from flows and leave loaded in memory until next call of new_data or release. 
   //int new_data(const std::string &timeslot, const flow_map_t &flow_map);
   
   // Store currently loaded stats into database
   int store() const;
   
   // Release all stats loaded in memory
   int release();
};

// Global vector of profiles available
extern std::vector<Profile*> profiles;

// Return the profile with a given name (if such profile doesn't exist, return NULL) 
Profile* getProfile(const std::string& name);

#endif
