#ifndef _IPADDR_H_
#define _IPADDR_H_

#include <stdint.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <string>
#include <iostream>

// auxiliary functions for swapping byte order
inline uint32_t swap_bytes_32(const uint32_t x)
{
   return ((x & 0x0000000ff) << 24) |
          ((x & 0x0000ff00) << 8) |
          ((x & 0x00ff0000) >> 8) |
          ((x & 0xff000000) >> 24);
}
inline uint64_t swap_bytes_64(const uint64_t x)
{
   return ((x & 0x00000000000000ffLL) << 56) |
          ((x & 0x000000000000ff00LL) << 40) |
          ((x & 0x0000000000ff0000LL) << 24) |
          ((x & 0x00000000ff000000LL) << 8) |
          ((x & 0x000000ff00000000LL) >> 8) |
          ((x & 0x0000ff0000000000LL) >> 24) |
          ((x & 0x00ff000000000000LL) >> 40) |
          ((x & 0xff00000000000000LL) >> 56);
}


/* IP address
 * Universal struct for both IPv4 and IPv6. Always occupies 128 bits,
 * in case of IPv4, higher 96 bits are zeros.
 * Assumes little-endian as native byte order.  
 */
struct IPAddr {
   uint64_t ad[2];
   
   // Constructors
   IPAddr() {
      ad[0] = 0; // low
      ad[1] = 0; // high
   }
   IPAddr(uint32_t ipv4, bool swap_byte_order = false)
   {
      if (swap_byte_order) {
         ad[0] = swap_bytes_32(ipv4) & 0x00000000ffffffffL;
      }
      else {
         ad[0] = ipv4 & 0x00000000ffffffffL;
      }
      ad[1] = 0;
   }
   IPAddr(uint64_t ipv6[2], bool swap_byte_order = false)
   {
      if (swap_byte_order) {
         ad[0] = swap_bytes_64(ipv6[1]);
         ad[1] = swap_bytes_64(ipv6[0]);
      }
      else {
         ad[0] = ipv6[0];
         ad[1] = ipv6[1];
      }
   }
   
   // Swap 64b blocks in IPv6
   IPAddr& swapBlocks() {
      uint64_t tmp = ad[0];
      ad[0] = ad[1];
      ad[1] = tmp;
      return *this;
   }
   
   // Get version
   bool isIPv6() const {
      return (ad[1] != 0);
   }
   bool isIPv4() const {
      return (ad[1] == 0);
   }
   int version() const {
      return (isIPv4() ? 4 : 6);
   }

   // Comparison operators
   bool operator<(const IPAddr &key2) const {
      return ((ad[1] < key2.ad[1]) ||
              ((ad[1] == key2.ad[1]) && (ad[0] < key2.ad[0])));
   }
   bool operator<=(const IPAddr &key2) const {
      return !(*this > key2);
   }
   bool operator>(const IPAddr &key2) const {
      return ((ad[1] > key2.ad[1]) ||
              ((ad[1] == key2.ad[1]) && (ad[0] > key2.ad[0])));
   }
   bool operator>=(const IPAddr &key2) const {
      return !(*this < key2);
   }
   bool operator==(const IPAddr &key2) const {
      return ((ad[1] == key2.ad[1]) && (ad[0] == key2.ad[0]));
   }
   bool operator!=(const IPAddr &key2) const {
      return !(*this == key2);
   }
   
   // String conversions
   std::string toString() const
   {
      char str[40];
      if (isIPv4()) { // IPv4
         uint32_t x = swap_bytes_32(ad[0]);
         inet_ntop(AF_INET, &x, str, 40);
      }
      else { // IPv6
         uint64_t x[2];
         x[0] = swap_bytes_64(ad[1]);
         x[1] = swap_bytes_64(ad[0]);
         inet_ntop(AF_INET6, x, str, 40);
      }
      return std::string(str);
   }
   
} __attribute__((packed));

inline std::ostream& operator<<(std::ostream &os, const IPAddr &ip)
{
   return os << ip.toString();
}

inline int str2ip(const std::string &str, IPAddr &ip)
{
   if (str.find(':') == std::string::npos) { // IPv4
      uint32_t tmp;
      if (inet_pton(AF_INET, str.c_str(), &tmp) == 1)
         ip = IPAddr(tmp, true);
      else
         return -1; // err
   }
   else { // IPv6
      char tmp[16];
      if (inet_pton(AF_INET6, str.c_str(), tmp) == 1)
         ip = IPAddr((uint64_t*)tmp, true);
      else
         return -1; // err
   }
   return 0; // ok
}


#endif
