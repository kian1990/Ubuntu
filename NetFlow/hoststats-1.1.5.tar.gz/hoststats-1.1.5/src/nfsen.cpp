/* Functions specific for getting data from nfsen.
 * Most of other files should be independent on the source of flow data.
 */ 

#include <vector>
#include <string>
#include <syslog.h>

#include "nfsen.h"
#include "aux_func.h"
#include "profile.h"
#include "hoststats.h"
#include "configuration.h"
#include "detectionrules.h"
#include "script.h"

#include <libnfdump.h>

using namespace std;

// Define callback function as simple C function
extern "C" {
   void callback_function(const master_record_t *nfrec, void *param);
}

struct callback_param_t {
   Profile *profile;
};

vector<callback_param_t> callback_params;

bool processing_data = false;
string last_timeslot = "none";

static uint64_t sourceindex; // Index of currently processed file (used for linkbitfield)

///////////////////////////////////////////////////////////////////////////////

// Function which gets called on every flow record matching a filter
void callback_function(const master_record_t *nfrec, void *param)
{
   callback_param_t *p = (callback_param_t*) param;
   
   // Convert libnfdump's master_record_t to hoststats' flow_record_t
   
   flow_key_t flow_key;
   flow_record_t flow_rec;
   
   // Set addresses to the key
   if (nfrec->flags & 0x1) { // IPv6
      flow_key.sad = IPAddr((uint64_t*)nfrec->ip_union._v6.srcaddr).swapBlocks();
   }
   else { // IPv4
      flow_key.sad = IPAddr(nfrec->ip_union._v4.srcaddr);
   }
   if (nfrec->flags & 0x1) { // IPv6
      flow_key.dad = IPAddr((uint64_t*)nfrec->ip_union._v6.dstaddr).swapBlocks();
   }
   else { // IPv4
      flow_key.dad = IPAddr(nfrec->ip_union._v4.dstaddr);
   }
   // Set ports and protocol in the key
   flow_key.sport = nfrec->srcport;
   flow_key.dport = nfrec->dstport;
   flow_key.proto = nfrec->prot;

   // Create the record with required info
   flow_rec.packets      = nfrec->dPkts;
   flow_rec.bytes        = nfrec->dOctets;
   flow_rec.tcp_flags    = nfrec->tcp_flags;
   flow_rec.linkbitfield = (0x1 << sourceindex);
   flow_rec.dirbitfield  = (0x1 << nfrec->input);

   p->profile->put_flow(flow_key, flow_rec);
}


///////////////////////////////////////////////////////////////////////////////

int nfsen_reader_init(const vector<Profile*> &profiles)
{
   int ret;
   
   if (nfdump_init() != 0) {
      log(LOG_ERR, "Error: Initialization of libnfdump failed.");
      return -1;
   }
   
   // Create callback_param_t for each profile
   for (unsigned int i = 0; i < profiles.size(); i++) {
      callback_param_t cbparam;
      cbparam.profile = profiles[i];
      callback_params.push_back(cbparam);
   }
   
   // Register callbacks
   for (unsigned int i = 0; i < profiles.size(); i++) {
      ret = nfdump_add_callback(callback_function, &callback_params[i],
                                profiles[i]->filter.c_str(), 0 );
      if (ret == NFDUMP_E_INVALID_FILTER) {
         log(LOG_ERR, "Error: Invalid filter in profile '%s'.", profiles[i]->filter.c_str());
         nfdump_cleanup();
         return 1;
      }
      else if (ret != 0) {
         log(LOG_ERR, "Error: registration of callback function failed (profile: %s).", profiles[i]->filter.c_str());
         nfdump_cleanup();
         return -2;
      }
   }
   
   processing_data = false;
   
   return 0;
}

// Gets called when new data (timeslot) are available.
// Starts processing of data in the new timeslot
void nfsen_reader_new_data(const string &ts)
{
   ///////////////////////////////////////////////////
   // Check and parse parameters and configuration
   
   // Check timeslot
   if (ts.size() != 12 || ts.find_first_not_of("0123456789") != string::npos) {
      log(LOG_ERR, "process_data: Invalid timeslot \"%s\"", ts.c_str());
      return;
   }
   
   // Safety check - if processing of previous timeslot is not completed,
   // don't start processing of new one to avoid machine overload
   if (processing_data) {
      log(LOG_NOTICE, "Can't process timeslot %s, previous timeslot hasn't been finished yet.", ts.c_str());
      return;
   }
   
   // Read configuration
   Configuration *conf = Configuration::getInstance();
   conf->lock();
   string flow_path = conf->getValue("flow-data-path");
   bool rules_generic = (conf->getValue("rules-generic") == "1");
   //bool rules_ssh = (conf->getValue("rules-ssh") == "1");
   string script_path = conf->getValue("timeslot-script");
   conf->unlock();
   
   if (flow_path == "") {
      log(LOG_ERR, "ERROR: process_data: Path to flow files is not specified in configuration.");
      return;
   }
   
   // Fill in time in flow_path
   replace(flow_path, "%y", ts.substr(0,4));
   replace(flow_path, "%m", ts.substr(4,2));
   replace(flow_path, "%d", ts.substr(6,2));
   replace(flow_path, "%H", ts.substr(8,2));
   replace(flow_path, "%M", ts.substr(10,2));
   
   // Fill source names in flow_path to get full file names
   vector<string> source_filenames;
   for (unsigned int i = 0; i < source_names.size(); i++) {
      string filename = flow_path;
      replace(filename, "%source", source_names[i]);
      source_filenames.push_back(filename);
   }
   
   //////////////////////////////////////////////////////////////
   // All parameters loaded and parsed, start data processing
   
   // Set status information
   processing_data = true;
   
   log(LOG_INFO, "Processing timeslot %s ...", ts.c_str());
   
   // Tell profiles that a new timeslot has started
   for (unsigned int i = 0; i < profiles.size(); i++) {
      profiles[i]->new_timeslot(ts);
   }
   
   // Process all files
   bool loaded = false;
   for (unsigned int i = 0; i < source_filenames.size(); i++) {
      int ecode;
      // Process a file and call a callback function for each profile 
      // for each flow matching the profile's filter.
      log(LOG_DEBUG, "Processing file '%s' ...", source_filenames[i].c_str());
      sourceindex = i; // index of current file, needed for linkbitfield
      ecode = nfdump_process_file(source_filenames[i].c_str());
      if (ecode == NFDUMP_E_OK) {
         loaded = true;
      } else if (ecode == NFDUMP_E_CANT_OPEN_FILE) {
         log(LOG_ERR, "Can't open file '%s'.", source_filenames[i].c_str());
      } else {
         log(LOG_ERR, "Error during processing of file '%s' (error code: %i)", source_filenames[i].c_str(), ecode);
      }
   }
   
   // Now, all profiles should contain statistics based on flow data from 
   // all files in the timeslot.
   
   if (loaded) {
      log(LOG_DEBUG, "Data of timeslot %s loaded.", ts.c_str());
   } else {
      log(LOG_INFO, "No data was loaded. Processing of timeslot %s terminated.", ts.c_str());
      goto end_processing;
   } 
   
   for (unsigned int i = 0; i < profiles.size(); i++) {
      log(LOG_DEBUG, "Profile '%s': %lu flows, %lu hosts.",
          profiles[i]->name.c_str(), profiles[i]->flows, profiles[i]->current_stat_map.size());
   }
   
   log(LOG_DEBUG, "Storing statistics into database ...");
   for (unsigned int i = 0; i < profiles.size(); i++) {
      profiles[i]->store();
   }
   
   if (script_path != "") {
      log(LOG_DEBUG, "Executing script ...");
      Script script(script_path);
      
      for (unsigned int i = 0; i < profiles.size(); i++) {
         script << ts << profiles[i]->name;
         script << profiles[i]->flows << profiles[i]->current_stat_map.size();
         script.execute();
         script.remove_args();
      }
   }
   
   log(LOG_DEBUG, "Running detectors ...");
   for (unsigned int i = 0; i < profiles.size(); i++) {
      // run all detectors associated with this profile
      // TODO: abstract class for detectors(or "analyzers"?), global list of active detectors, here loop over this list
      if (rules_generic && profiles[i]->name == "all")
         check_rules(profiles[i]);
//       if (rules_ssh && profiles[i]->name == "ssh")
//          check_rules_ssh(profiles[i]);
      profiles[i]->release();
   }
   log(LOG_DEBUG, "Detectors finished, statistics released from memory.");
   
   log(LOG_INFO, "Processing of timeslot %s done.", ts.c_str());

end_processing:
   last_timeslot = ts;
   processing_data = false;
}


int nfsen_reader_cleanup()
{
   nfdump_cleanup();
   return 0;
}
