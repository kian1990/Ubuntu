<?php

/**
 * RGB color generation class
 * @author Lukas Hutak <xhutak01@stud.fit.vutbr.cz>
 * @package HostStats/Frontend
 */

class Color {
    /**
     * Generate a color
     * Select the color from color palette according to the specified number
     * @param int $num Positive number of color 
     * @return string String with RGB color, format "#RRGGBB"
     */
    public static function get_rgb_color($num)
    {
        // more info: http://krazydad.com/tutorials/makecolors.php
        $frequency = 0.55;
        $red = sin($frequency * $num + 0) * 127 + 128;
        $green = sin($frequency * $num + 2) * 127 + 128;
        $blue = sin($frequency * $num + 4) * 127 + 128;
        
        return self::rgb2color($red, $green, $blue);
    }
    
    /**
     * Convert RGB values to RGB hex specification
     * @param int $r Red
     * @param int $g Green
     * @param int $b Blue
     * @return string RGB color specification in format "#RRGGBB"
     */
    protected static function rgb2color($r, $g, $b)
    {
        return '#' . self::byte2hex($r) . self::byte2hex($g) . self::byte2hex($b);
    }
    
    /**
     * Convert byte to hex 
     * @param int $n Byte
     * @return string Byte in hex (only from "00" to "FF")
     */
    protected static function byte2hex($n) 
    {
        $hex_values = "0123456789ABCDEF";
        return 
            substr($hex_values, ($n >> 4) & 0x0F, 1) . 
            substr($hex_values, ($n & 0x0F), 1);
    }
}
