<?php

/**
 * Overview presenter.
 * @author Petr Sladek <xslade12@stud.fit.vutbr.cz>
 * @package HostStats/Frontend
 */
class OverviewPresenter extends BasePresenter
{

    /**
     * Prepare Default view
     */
    public function renderDefault()
	{
        try {
            $status = $this->model->getStatus();

            $from = $status->timeslot ? $status->timeslot->getModify('- 12 hours') : null;
            $to = $status->timeslot ? $status->timeslot : null;

            $history = $this->model->getFlowCntHistory(HSConnection::ALL, $to, $to);
            $status->flows = current($history);
            $history = $this->model->getHostCntHistory(HSConnection::ALL, $to, $to);
            $status->hosts = current($history);

            $this->template->status = $status;

            // Prepare profiles
            $list_of_profiles = array();
            foreach ($this->profiles as $index => $profile) {
                // profile[0] = name, profile[1] = color (color can be unset)
                $list_of_profiles[] = array(
                    'name' =>  $profile[0],
                    'color' => $profile[1] 
                        ? ('#' . $profile[1])
                        : Color::get_rgb_color($index) //color is unset, generate new one
                );
            }
            
            // Graph of active flows
            foreach($list_of_profiles as $profile) {
                //if($profile!='all')
                    $flowCntHistory[] = array(
                        'label' => $profile['name'],
                        'color' => $profile['color'],
                        'data' => $this->model->getFlowCntHistory($profile['name'], $from, $to),
                    );
            }
            $this->template->chartHistoryFlows = Json::encode( $flowCntHistory );
            $this->payload->chartHistoryFlows = $flowCntHistory; // because of ajax refresh

            // Graph of active hosts
            foreach($list_of_profiles as $profile) {
                //if($profile!='all')
                    $hostCntHistory[] = array(
                        'label' => $profile['name'],
                        'color' => $profile['color'],
                        'data' => $this->model->getHostCntHistory($profile['name'], $from, $to)
                    );
            }
            $this->template->chartHistoryHosts = Json::encode($hostCntHistory);
            $this->payload->chartHistoryHosts = $hostCntHistory; // because of ajax refresh


            if(!$this->isAjax()) {
                // Last detections
                $this->template->lastDetections = $this->model->getDetectionLogList("desc",10);
            }

        } catch(HSCException $e) {
            $this->flashMessage($e->getMessage(), 'error');
        }
    }

    /**
     * Do signal refresh!
     */
    public function handleRefresh() {
        if($this->isAjax())
            $this->invalidateControl();
        else
            $this->redirect('this');
    }



}
