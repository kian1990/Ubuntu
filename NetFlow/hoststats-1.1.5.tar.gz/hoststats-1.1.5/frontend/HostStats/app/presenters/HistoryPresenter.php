<?php

/**
 * History presenter.
 * @author Petr Sladek <xslade12@stud.fit.vutbr.cz>
 * @package HostStats/Frontend
 */
class HistoryPresenter extends BasePresenter
{

    /** @persistent */
    public $from;
    /** @persistent */
    public $to;
    /** @persistent */
    public $ip;

    public $window;

    /**
     * prepare parameters in Default action
     * @param string|null $ip
     */
    public function actionDefault($ip=null) {

        $from = new Timeslot($this->from ? $this->from : '- 1 hour');
        $to = new Timeslot($this->to ? $this->to : null);

        try {
            $this->window = new Timewindow($from, $to);
        } catch(TimewindowException $e) {
            $from = new Timeslot('- 1 hour');
            $to = new Timeslot(null);
            $this->window = new Timewindow($from, $to);
            $this->flashMessage($e->getMessage(), 'error');
        }

    }

    /**
     * prepare Default view
     * @param string|null $ip
     */
    public function renderDefault($ip=null)
	{
        $this->template->ip = $this->ip;
        $this->template->timewindow = $this->window;


        // If IP is set, get data
        if($this->ip) {
            try{
                // Check whether address is valid
                if(!Nettools::isIP($this->ip))
                    throw new HSCBadCommandException("'{$this->ip}' is not a valid IP address");

                $this->template->flow_sources = $this->model->getFlowSources();
                $list = $this->model->getHostHistory( $this->ip, $this->profile, $this->window->from, $this->window->to );
                $this->template->list = $list;
                $this->template->chartHistoryIp = $this->_getListForChart( $list );

            } catch(HSCBadCommandException $e) {
                $this->flashMessage($e->getMessage(), "error");
            }
        }

        $this['frmTimewindow']->setDefaults(array(
            'from' => $this->window->from->format( $this->formats->timeslot ),
            'to' => $this->window->to->format( $this->formats->timeslot )
        ));

        $this->template->whois_enabled = !empty($this->context->parameters['nettools']['whois']['enabled']) &&
            filter_var($this->context->parameters['nettools']['whois']['enabled'], FILTER_VALIDATE_BOOLEAN);


        if($this->isAjax())
            $this->invalidateControl();
	}

    /**
     * Convert list to json for charts
     * @param array $list
     * @return string JSON
     */
    protected function _getListForChart( $list ) {
        $result = array();
        foreach($list as $item)
            $result[$item->timeslot->getLocalTimestamp()] = $item;
        return Json::encode($result);
    }

    /**
     * Do signal windowPrev!
     */
    public function handleWindowPrev() {
        // Posuneme okno
        $this->window->prev();
        // Update persistent parameters
        $this->from = $this->window->from->getName();
        $this->to = $this->window->to->getName();

        if($this->isAjax())
            $this->invalidateControl();
        else
            $this->redirect('this');
    }
    /**
     * Do signal windowNext!
     */
    public function handleWindowNext() {
        // Posuneme okno
        $this->window->next();
        // Update persistent parameters
        $this->from = $this->window->from->getName();
        $this->to = $this->window->to->getName();

        if($this->isAjax())
            $this->invalidateControl();
        else
            $this->redirect('this');
    }
    /**
     * Do signal windowSet!
     */
    public function handleWindowSet($from=null,$to=null) {

        try {
            $this->window = new Timewindow(new Timeslot($from), new Timeslot($to));
        } catch(TimewindowException $e) {
            $this->flashMessage($e->getMessage(), 'error');
        }
        // Update persistent parameters
        $this->from = $this->window->from->getName();
        $this->to = $this->window->to->getName();

        if($this->isAjax())
            $this->invalidateControl();
        else
            $this->redirect('this');
    }


    /**
     * Create IP address form
     * @return AppForm
     */
    public function createComponentFrmIpAddress() {
        $frm = new AppForm();
        $frm->addText('ip','IP address')
            ->setDefaultValue($this->ip)
            ->setHtmlID('ipaddress');
        $frm->addSubmit('send','Send');
        $frm->onSuccess[] = array($this,'frmIpAddressSuccess');
        return $frm;
    }

    /**
     * Callbeck on success IP address form
     * @param Form $frm
     */
    public function frmIpAddressSuccess(Form $frm) {
        $this->ip = $frm->values->ip;

        if($this->isAjax())
            $this->invalidateControl();
        else
            $this->redirect('this');
    }

    /**
     * Create timewindow form
     * @return AppForm
     */
    public function createComponentFrmTimewindow() {
        $frm = new AppForm();
        $frm->addText('from','From');
        $frm->addText('to','To');
        $frm->addSubmit('send','Submit');
        $frm->onSuccess[] = array($this,'frmTimewindowSuccess');
        return $frm;
    }

    /**
     * Callbeck on success timewindow from
     * @param Form $frm
     */
    public function frmTimewindowSuccess(Form $frm) {

        $from = $frm->values->from;
        $to = $frm->values->to;

        try {
            $this->window = new Timewindow(new Timeslot($from), new Timeslot($to));
        } catch(TimewindowException $e) {
            $this->flashMessage($e->getMessage(), 'error');
        }

        // Actuliye persistent params
        $this->from = $this->window->from->getName();
        $this->to = $this->window->to->getName();

        if($this->isAjax())
            $this->invalidateControl();
        else
            $this->redirect('this');
    }

    /**
     * Prepare Whois view
     * @param $ip
     */
    public function renderWhois($ip) {

        $host = !empty($this->context->parameters['nettools']['whois']['host']) ? $this->context->parameters['nettools']['whois']['host'] : null;
        $this->template->whois = $ip ? Nettools::whois($this->ip, $host) : null;
    }



}
