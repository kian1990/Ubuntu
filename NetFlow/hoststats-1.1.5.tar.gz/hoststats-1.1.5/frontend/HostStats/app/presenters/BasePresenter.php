<?php

/**
 * Base presenter for all application presenters.
 * @author Petr Sladek <xslade12@stud.fit.vutbr.cz>
 * @package HostStats/Frontend
 */
abstract class BasePresenter extends Presenter
{

    /** @var Data model */
    protected $model;

    /** @persistent  */
    public $profile = HSConnection::ALL;
    
    /** @persistent  */
    public $timeslot;

    /** @var All available profiles */
    protected $profiles;
    /** @var Formats from config */
    protected $formats;
    /** @var Data from configuration file */
    protected $config;
    /** @var Server connection status */
    protected $server_running;
    /** @var Error message in case of server connection failure */
    protected $server_error;

    /** Begin of application life cycle */
    public function startup() {


        $this->config = ArrayHash::from( $this->context->parameters );
        $this->model = new Model( $this->context->getService('conn') );
        $this->formats = ArrayHash::from( $this->context->parameters['formats'] );
         
        $this->server_running = true;
        $this->server_error = "";

        try {
            $this->profiles = $this->model->getProfiles();
        } catch(HSCConnectException $e) {
            $this->server_running = false;
            $this->server_error = $e->getMessage();
        }
        
        // If server is not running, set strings needed for an error message
        if (!$this->server_running) {
            $this->template->basedir = $this->context->parameters['hoststats']['basedir'];
            $this->template->socketfilename = $this->model->conn->socketfilename;
        }
        
        parent::startup();
    }


    /**
     * Generate profiles form
     * @return AppForm
     */
    public function createComponentFrmProfile() {
        $frm = new AppForm();
        
        $frm_select_arg = array();
        foreach ($this->profiles as $profiles) {
            $frm_select_arg[$profiles[0]] = $profiles[0];
        }
        
        $frm->addSelect("profile", "Profile:", $frm_select_arg)
            ->setDefaultValue($this->profile);
        $frm->addSubmit("send","Submit");
        $frm->onSuccess[] = array($this, 'frmProfileSuccess');
        return $frm;
    }

    /**
     * Callback on success profiles form
     * @param Form $frm
     */
    public function frmProfileSuccess(Form $frm) {
        $this->profile = $frm->values->profile;
        if(!$this->isAjax())
            $this->redirect('this');
    }

    /**
     * Prepare template before rendering
     */
    public function beforeRender() {
        $this->template->formats = $this->formats;
        $this->template->config = $this->config;
        $this->template->registerHelper('syntax', array($this,'helperGeSHi'));
        
        $this->template->server_running = $this->server_running;
        $this->template->server_error = $this->server_error;

        $this->payload->link = $this->link('this');
    }

    /**
     * Create helper to GeSHi syntax highlighter
     * @param string $s
     * @param string $lang
     * @return mixed
     */
    public function helperGeSHi($s, $lang = 'whois') {
        $geshi = new GeSHi($s, $lang);
        return  $geshi->parse_code();
    }
    
}
