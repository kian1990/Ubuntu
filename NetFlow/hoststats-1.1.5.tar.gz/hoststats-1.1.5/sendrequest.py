#!/usr/bin/python

# This script can be used to test hoststatserv.
# It allows to send arbitrary request with parameters to HostStats daemon via
# communication socket and print reply.
# Example usage (GET_HOST_HISTORY request):
#  ./sendrequest.py /data/hoststats/sock.comm 35 "all;1.2.3.4;201303020100;201303020155"

from socket import *
import sys

help_string = """This script can be used to test hoststatserv.
It allows to send arbitrary request with parameters to HostStats daemon via
communication socket and print reply.

Usage: ./sendrequest.py socket-file request-code params

Example (GET_HOST_HISTORY request):
 ./sendrequest.py /data/hoststats/sock.comm 35 "all;1.2.3.4;201303020100;201303020155"

Valid request codes:
  Name (code)               Parameters
-------------------------------------------------------------------------------
  NEW_DATA (1)              "timeslot"
    Message called when new data are available. No reply is returned.
    Format of timeslot: YYYYMMDDHHMM

  GET_STATUS (10)           (none)
    Get basic statistics about program (time, flows & host loaded, etc.)

  GET_HOST_CNT_HISTORY (11) "profile;start_timeslot;end_timeslot" 
    Get history of number of hosts

  GET_FLOW_CNT_HISTORY (12) "profile;start_timeslot;end_timeslot" 
    Get history of number of flows

  GET_PROFILES (20)         (none)
    Get a list of available profiles

  GET_FIELD_LIST (30)       (none)
    Get a list of fields in a host record

  GET_TIMESLOT_DATA (31)    "profile;timeslot;filter;limit;sort_by;asc"
    Get stats about all addresses from a given timeslot
      limit - max. number of returned records (0 = unlimited)
      sort_by - name of field to sort records by
      asc - sorting order, 1 = ascending, 0 = descending

  GET_TIMESLOT_IPMAP (32)   "profile;timeslot;prefix;prefix_length"
    Get stats aggregated by given prefix to create an IP map
      prefix - IPv4 address
      prefix_length - length of prefix (0-16)

  GET_HOST_HISTORY (35)     "profile;address;start_timeslot;end_timeslot"
    Get all records of a single host in given time range

  GET_DETECTION_LOG_LIST (40) (none)
    Get a list of available detection log files

  GET_DETECTION_LOG (41)      day
    Get contents of detection log file (format of param: YYYYMMDD)
"""

if "-h" in sys.argv or "--help" in sys.argv:
   print help_string
   exit(0)

if len(sys.argv) == 4:
   socketfile = sys.argv[1]
   code = int(sys.argv[2])
   params = sys.argv[3]
else:
   print "Usage:", sys.argv[0], "socket-file request-code params"
   exit(1)

s = socket(AF_UNIX, SOCK_STREAM)
s.connect(socketfile)

s.sendall(chr(code)+params)
s.shutdown(1)

reply = s.recv(1024)
while (reply):
   sys.stdout.write(reply)
   reply = s.recv(1024)

s.close()
