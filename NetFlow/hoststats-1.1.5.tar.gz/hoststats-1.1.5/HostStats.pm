#!/usr/bin/perl

# HostStats plugin for NfSen

# Name of the plugin
package HostStats;

use strict;
use NfProfile;
use NfConf;
use IO::Socket::UNIX;
# The plugin may send any messages to syslog
# Do not initialize syslog, as this is done by 
# the main process nfsen-run
use Sys::Syslog;

my $BASE_DIR = "REPLACE_THIS_BY_INSTALLATION_PATH";

my $SOCKET_PATH = $BASE_DIR . "/comm.sock";

our %cmd_lookup = ( );

# This string identifies the plugin as a version 1.3.0 plugin. 
our $VERSION = 130;

my $MSG_NEW_DATA = "\x01";

#
# Periodic data processing function
#	input:	hash reference including the items:
#			'profile'		profile name
#			'profilegroup'	profile group
#			'timeslot' 		time of slot to process: Format yyyymmddHHMM e.g. 200503031200
sub run {
	my $argref 		 = shift;
	my $profile 	 = $$argref{'profile'};
	my $profilegroup = $$argref{'profilegroup'};
	my $timeslot 	 = $$argref{'timeslot'};

	syslog('info', "HostStats run: Profilegroup: $profilegroup, Profile: $profile, Time: $timeslot");
	my $cpp_socket = new IO::Socket::UNIX (
		Type => SOCK_STREAM,
		Peer => $SOCKET_PATH
	) or die "ERROR: Can't connect to communication socket [$SOCKET_PATH]: $!\n";

	$cpp_socket->send("$MSG_NEW_DATA$timeslot\0");
	
	$cpp_socket->close();
	syslog('info', "HostStats: NewData request sent");
	return;
}


#
# The Init function is called when the plugin is loaded. It's purpose is to give the plugin 
# the possibility to initialize itself. The plugin should return 1 for success or 0 for 
# failure. If the plugin fails to initialize, it's disabled and not used. Therefore, if
# you want to temporarily disable your plugin return 0 when Init is called.
#
sub Init {
	syslog("info", "HostStats plugin: Init");

	#$PROFILEDIR = "$NfConf::PROFILEDATADIR";
	
	return 1;
}

#
# The Cleanup function is called, when nfsend terminates. It's purpose is to give the
# plugin the possibility to cleanup itself. It's return value is discard.
#sub Cleanup {
#	syslog("info", "HostStats plugin: Cleanup");
#}

1;
